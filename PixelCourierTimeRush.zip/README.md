# Pixel Courier: Time Rush

A retro-style 2D side-scrolling delivery game with pixel art graphics, procedural level generation, and power-ups.

## Game Features

- Retro pixel art graphics
- Side-scrolling delivery gameplay with touch controls
- Countdown timer and increasing difficulty
- Procedural level generation with random obstacles
- Power-ups and collectible coins
- Sound effects and background music
- Start screen, pause, and game-over menus

## Build Instructions

### Prerequisites

- Android Studio (latest version recommended)
- JDK 11 or higher
- Android SDK 31 or higher

### Importing the Project

1. Extract the source code zip file to a location on your computer
2. Open Android Studio
3. Select "Open an existing Android Studio project"
4. Navigate to the extracted folder and select it
5. Wait for Gradle sync to complete

### Building the APK

1. In Android Studio, go to Build > Build Bundle(s) / APK(s) > Build APK(s)
2. Wait for the build process to complete
3. The APK will be generated in the app/build/outputs/apk/debug/ directory
4. You can also build a signed APK by going to Build > Generate Signed Bundle / APK

### Installing the APK

1. Enable "Install from Unknown Sources" in your Android device settings
2. Transfer the APK file to your Android device
3. Tap on the APK file to install it
4. Launch the game from your app drawer

## Game Controls

- **Tap anywhere**: Make the courier jump
- **Tap pause button**: Pause the game
- **Tap menu buttons**: Navigate through menus

## Game Mechanics

### Objective
Deliver packages by navigating through obstacles while collecting coins and power-ups before the timer runs out.

### Power-ups
- **Clock**: Adds extra time to the countdown
- **Lightning**: Increases speed temporarily
- **Shield**: Provides temporary invincibility
- **Magnet**: Attracts nearby coins

### Scoring
- Collect coins to increase your score
- Avoid obstacles to maintain your delivery time
- The game ends when the timer reaches zero

## Project Structure

- `android/src/main/java/com/pixelcourier/timerush/`: Main source code
  - `game/`: Core game mechanics and objects
  - `ui/`: User interface components
  - `audio/`: Sound effects and music handling
  - `effects/`: Visual effects system
- `android/src/main/assets/`: Game assets
  - `sprites/`: All game graphics
  - `sounds/`: Sound effects
  - `music/`: Background music tracks
- `android/src/main/res/`: Android resources
  - `values/`: String resources and styles
  - `layout/`: XML layout files

## Development Notes

The game was developed using a custom game framework built on Android's Canvas API. The framework includes:

- Game loop with delta time for consistent gameplay across devices
- Asset management system for sprites and audio
- Collision detection system
- Procedural level generation
- Particle effects system

## Troubleshooting

If you encounter any issues during building or gameplay:

1. Ensure you have the latest Android Studio and SDK tools
2. Check that your device meets the minimum requirements (Android 8.0+)
3. Make sure all permissions are granted to the app
4. Try cleaning and rebuilding the project in Android Studio

## Credits

- Game developed by Manus AI
- Pixel art assets created programmatically
- Sound effects and music generated using Python with scipy

## License

This game is provided for educational purposes. All rights reserved.
