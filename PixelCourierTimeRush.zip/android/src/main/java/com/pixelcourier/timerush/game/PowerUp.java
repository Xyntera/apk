package com.pixelcourier.timerush.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Implementation of power-ups for Pixel Courier: Time Rush
 * Extends the GameObject class with specific power-up behavior
 */
public class PowerUp extends GameObject {
    // Power-up types
    public static final int TYPE_CLOCK = 0;     // Extra time
    public static final int TYPE_SPEED = 1;     // Speed boost
    public static final int TYPE_SHIELD = 2;    // Invincibility
    public static final int TYPE_MAGNET = 3;    // Coin attractor
    
    // Power-up properties
    private int type;
    private float speed;
    private float floatOffset;
    private float floatTimer;
    
    // References
    private AssetManager assetManager;
    
    public PowerUp(float x, float y, float width, float height, int type, float speed, AssetManager assetManager) {
        super(x, y, width, height);
        this.type = type;
        this.speed = speed;
        this.assetManager = assetManager;
        this.velocityX = -speed; // Move left
        this.floatOffset = 0;
        this.floatTimer = 0;
    }
    
    @Override
    public void update(float deltaTime) {
        // Update position based on velocity
        x += velocityX * deltaTime;
        
        // Add floating effect
        floatTimer += deltaTime * 3.0f;
        floatOffset = (float) Math.sin(floatTimer) * 5.0f;
        
        // Update collision box
        updateCollisionBox();
    }
    
    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        
        // Draw power-up sprite with floating effect
        assetManager.drawFrame(canvas, "powerups", type, 
                              AssetManager.POWERUP_FRAME_WIDTH, 
                              AssetManager.POWERUP_FRAME_HEIGHT, 
                              x, y + floatOffset, paint);
    }
    
    /**
     * Check if power-up is off screen
     */
    public boolean isOffScreen() {
        return x + width < 0;
    }
    
    /**
     * Get power-up type
     */
    public int getType() {
        return type;
    }
}
