package com.pixelcourier.timerush.audio;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Build;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Audio Manager for Pixel Courier: Time Rush
 * Handles loading and playing sound effects and background music
 */
public class AudioManager {
    private static final String TAG = "AudioManager";
    
    // Sound constants
    public static final int SOUND_JUMP = 1;
    public static final int SOUND_COIN = 2;
    public static final int SOUND_POWERUP = 3;
    public static final int SOUND_CRASH = 4;
    public static final int SOUND_GAME_OVER = 5;
    public static final int SOUND_BUTTON_CLICK = 6;
    public static final int SOUND_TIME_LOW = 7;
    
    // Music constants
    public static final int MUSIC_MENU = 1;
    public static final int MUSIC_GAMEPLAY = 2;
    public static final int MUSIC_GAME_OVER = 3;
    
    // Audio resources
    private Context context;
    private SoundPool soundPool;
    private Map<Integer, Integer> soundMap;
    private MediaPlayer musicPlayer;
    private int currentMusic;
    private float musicVolume;
    private float soundVolume;
    private boolean soundEnabled;
    private boolean musicEnabled;
    
    public AudioManager(Context context) {
        this.context = context;
        this.soundMap = new HashMap<>();
        this.currentMusic = -1;
        this.musicVolume = 0.5f;
        this.soundVolume = 1.0f;
        this.soundEnabled = true;
        this.musicEnabled = true;
        
        // Initialize SoundPool
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
            
            soundPool = new SoundPool.Builder()
                .setMaxStreams(10)
                .setAudioAttributes(attributes)
                .build();
        } else {
            soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        }
        
        // Load sound effects
        loadSounds();
    }
    
    /**
     * Load all sound effects
     */
    private void loadSounds() {
        try {
            // Load sound effects from assets
            soundMap.put(SOUND_JUMP, soundPool.load(context.getAssets().openFd("sounds/jump.wav"), 1));
            soundMap.put(SOUND_COIN, soundPool.load(context.getAssets().openFd("sounds/coin.wav"), 1));
            soundMap.put(SOUND_POWERUP, soundPool.load(context.getAssets().openFd("sounds/powerup.wav"), 1));
            soundMap.put(SOUND_CRASH, soundPool.load(context.getAssets().openFd("sounds/crash.wav"), 1));
            soundMap.put(SOUND_GAME_OVER, soundPool.load(context.getAssets().openFd("sounds/game_over.wav"), 1));
            soundMap.put(SOUND_BUTTON_CLICK, soundPool.load(context.getAssets().openFd("sounds/button_click.wav"), 1));
            soundMap.put(SOUND_TIME_LOW, soundPool.load(context.getAssets().openFd("sounds/time_low.wav"), 1));
        } catch (Exception e) {
            Log.e(TAG, "Error loading sounds", e);
        }
    }
    
    /**
     * Play a sound effect
     */
    public void playSound(int soundId) {
        if (!soundEnabled) {
            return;
        }
        
        Integer soundResourceId = soundMap.get(soundId);
        if (soundResourceId != null) {
            soundPool.play(soundResourceId, soundVolume, soundVolume, 1, 0, 1.0f);
        }
    }
    
    /**
     * Play a sound effect with custom volume and rate
     */
    public void playSound(int soundId, float volume, float rate) {
        if (!soundEnabled) {
            return;
        }
        
        Integer soundResourceId = soundMap.get(soundId);
        if (soundResourceId != null) {
            soundPool.play(soundResourceId, volume * soundVolume, volume * soundVolume, 1, 0, rate);
        }
    }
    
    /**
     * Play a sound effect with looping
     */
    public int playSoundLooped(int soundId) {
        if (!soundEnabled) {
            return -1;
        }
        
        Integer soundResourceId = soundMap.get(soundId);
        if (soundResourceId != null) {
            return soundPool.play(soundResourceId, soundVolume, soundVolume, 1, -1, 1.0f);
        }
        return -1;
    }
    
    /**
     * Stop a looping sound
     */
    public void stopSound(int streamId) {
        if (streamId != -1) {
            soundPool.stop(streamId);
        }
    }
    
    /**
     * Play background music
     */
    public void playMusic(int musicId) {
        if (!musicEnabled || currentMusic == musicId) {
            return;
        }
        
        // Stop current music if playing
        stopMusic();
        
        try {
            // Create and configure MediaPlayer
            musicPlayer = new MediaPlayer();
            
            // Set music file based on ID
            String musicFile;
            switch (musicId) {
                case MUSIC_MENU:
                    musicFile = "music/menu_music.mp3";
                    break;
                case MUSIC_GAMEPLAY:
                    musicFile = "music/gameplay_music.mp3";
                    break;
                case MUSIC_GAME_OVER:
                    musicFile = "music/game_over_music.mp3";
                    break;
                default:
                    return;
            }
            
            // Load and play music
            musicPlayer.setDataSource(context.getAssets().openFd(musicFile));
            musicPlayer.setLooping(true);
            musicPlayer.setVolume(musicVolume, musicVolume);
            musicPlayer.prepare();
            musicPlayer.start();
            
            currentMusic = musicId;
        } catch (Exception e) {
            Log.e(TAG, "Error playing music", e);
            musicPlayer = null;
        }
    }
    
    /**
     * Stop background music
     */
    public void stopMusic() {
        if (musicPlayer != null) {
            if (musicPlayer.isPlaying()) {
                musicPlayer.stop();
            }
            musicPlayer.release();
            musicPlayer = null;
            currentMusic = -1;
        }
    }
    
    /**
     * Pause background music
     */
    public void pauseMusic() {
        if (musicPlayer != null && musicPlayer.isPlaying()) {
            musicPlayer.pause();
        }
    }
    
    /**
     * Resume background music
     */
    public void resumeMusic() {
        if (musicEnabled && musicPlayer != null && !musicPlayer.isPlaying()) {
            musicPlayer.start();
        }
    }
    
    /**
     * Set music volume
     */
    public void setMusicVolume(float volume) {
        this.musicVolume = volume;
        if (musicPlayer != null) {
            musicPlayer.setVolume(musicVolume, musicVolume);
        }
    }
    
    /**
     * Set sound effects volume
     */
    public void setSoundVolume(float volume) {
        this.soundVolume = volume;
    }
    
    /**
     * Enable/disable sound effects
     */
    public void setSoundEnabled(boolean enabled) {
        this.soundEnabled = enabled;
    }
    
    /**
     * Enable/disable background music
     */
    public void setMusicEnabled(boolean enabled) {
        this.musicEnabled = enabled;
        if (enabled) {
            resumeMusic();
        } else {
            pauseMusic();
        }
    }
    
    /**
     * Release all audio resources
     */
    public void release() {
        stopMusic();
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
    }
}
