package com.pixelcourier.timerush.game;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;

/**
 * Implementation of the player character for Pixel Courier: Time Rush
 * Extends the GameObject class with specific player behavior
 */
public class Player extends GameObject {
    // Player constants
    private static final float MOVE_SPEED = 500f;
    private static final float MAX_VELOCITY = 800f;
    private static final float GRAVITY = 1200f;
    private static final float JUMP_FORCE = -800f;
    private static final int MAX_LIVES = 3;
    
    // Player state
    private int lives;
    private boolean isJumping;
    private boolean isInvulnerable;
    private float invulnerabilityTimer;
    private float speedBoostTimer;
    private float magnetTimer;
    private boolean hasSpeedBoost;
    private boolean hasMagnet;
    
    // Animation
    private int currentFrame;
    private float frameTimer;
    private static final float FRAME_DURATION = 0.1f; // seconds per frame
    
    // References
    private AssetManager assetManager;
    
    public Player(float x, float y, float width, float height, AssetManager assetManager) {
        super(x, y, width, height);
        this.assetManager = assetManager;
        this.lives = MAX_LIVES;
        this.isJumping = false;
        this.isInvulnerable = false;
        this.invulnerabilityTimer = 0;
        this.speedBoostTimer = 0;
        this.magnetTimer = 0;
        this.hasSpeedBoost = false;
        this.hasMagnet = false;
        this.currentFrame = 0;
        this.frameTimer = 0;
    }
    
    @Override
    public void update(float deltaTime) {
        // Update position based on velocity
        x += velocityX * deltaTime;
        y += velocityY * deltaTime;
        
        // Apply gravity if jumping
        if (isJumping) {
            velocityY += GRAVITY * deltaTime;
        }
        
        // Check if landed
        if (y > 400 - height) { // Assuming ground is at y=400
            y = 400 - height;
            velocityY = 0;
            isJumping = false;
        }
        
        // Apply friction to x velocity
        velocityX *= 0.9f;
        
        // Keep player on screen
        if (x < 0) x = 0;
        if (x > 800 - width) x = 800 - width; // Assuming screen width of 800
        
        // Update collision box
        updateCollisionBox();
        
        // Update invulnerability
        if (isInvulnerable) {
            invulnerabilityTimer -= deltaTime;
            if (invulnerabilityTimer <= 0) {
                isInvulnerable = false;
            }
        }
        
        // Update speed boost
        if (hasSpeedBoost) {
            speedBoostTimer -= deltaTime;
            if (speedBoostTimer <= 0) {
                hasSpeedBoost = false;
            }
        }
        
        // Update magnet
        if (hasMagnet) {
            magnetTimer -= deltaTime;
            if (magnetTimer <= 0) {
                hasMagnet = false;
            }
        }
        
        // Update animation
        frameTimer += deltaTime;
        if (frameTimer >= FRAME_DURATION) {
            frameTimer = 0;
            currentFrame = (currentFrame + 1) % AssetManager.PLAYER_FRAME_COUNT;
        }
    }
    
    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        
        // Flash if invulnerable
        if (isInvulnerable && (int)(invulnerabilityTimer * 10) % 2 == 0) {
            paint.setAlpha(128);
        }
        
        // Draw player sprite
        assetManager.drawFrame(canvas, "player", currentFrame, 
                              AssetManager.PLAYER_FRAME_WIDTH, 
                              AssetManager.PLAYER_FRAME_HEIGHT, 
                              x, y, paint);
        
        // Reset alpha
        paint.setAlpha(255);
        
        // Draw power-up indicators
        if (hasSpeedBoost) {
            // Draw speed boost indicator
            canvas.drawCircle(x + width / 2, y - 10, 5, paint);
        }
        
        if (hasMagnet) {
            // Draw magnet indicator
            canvas.drawCircle(x + width / 2, y - 20, 5, paint);
        }
    }
    
    /**
     * Handle player movement based on touch input
     */
    public void handleTouch(float touchX, float touchY) {
        // Move left/right based on touch position relative to player
        if (touchX < x + width / 2) {
            moveLeft();
        } else {
            moveRight();
        }
        
        // Jump if touch is above player
        if (touchY < y && !isJumping) {
            jump();
        }
    }
    
    /**
     * Move player left
     */
    public void moveLeft() {
        float speed = hasSpeedBoost ? MOVE_SPEED * 1.5f : MOVE_SPEED;
        velocityX = -speed;
        if (velocityX < -MAX_VELOCITY) velocityX = -MAX_VELOCITY;
    }
    
    /**
     * Move player right
     */
    public void moveRight() {
        float speed = hasSpeedBoost ? MOVE_SPEED * 1.5f : MOVE_SPEED;
        velocityX = speed;
        if (velocityX > MAX_VELOCITY) velocityX = MAX_VELOCITY;
    }
    
    /**
     * Make player jump
     */
    public void jump() {
        if (!isJumping) {
            isJumping = true;
            velocityY = JUMP_FORCE;
            
            // Play jump sound
            GameEngine.getAudioManager().playSound(AudioManager.SOUND_JUMP);
            
            // Create jump visual effect
            GameEngine.getEffectsManager().createJumpEffect(x, y);
        }
    }
    
    /**
     * Handle collision with an obstacle
     */
    public boolean hitObstacle() {
        if (!isInvulnerable) {
            lives--;
            isInvulnerable = true;
            invulnerabilityTimer = 2.0f; // 2 seconds of invulnerability
            return true;
        }
        return false;
    }
    
    /**
     * Apply power-up effect
     */
    public void applyPowerUp(int type) {
        switch (type) {
            case 0: // Clock (extra time)
                // This is handled by the game engine
                break;
            case 1: // Speed boost
                hasSpeedBoost = true;
                speedBoostTimer = 10.0f; // 10 seconds of speed boost
                break;
            case 2: // Shield (invincibility)
                isInvulnerable = true;
                invulnerabilityTimer = 10.0f; // 10 seconds of invincibility
                break;
            case 3: // Magnet (coin attractor)
                hasMagnet = true;
                magnetTimer = 10.0f; // 10 seconds of coin attraction
                break;
        }
    }
    
    /**
     * Add a life
     */
    public void addLife() {
        if (lives < MAX_LIVES) {
            lives++;
        }
    }
    
    /**
     * Check if player is game over
     */
    public boolean isGameOver() {
        return lives <= 0;
    }
    
    /**
     * Get player lives
     */
    public int getLives() {
        return lives;
    }
    
    /**
     * Check if player has magnet power-up
     */
    public boolean hasMagnet() {
        return hasMagnet;
    }
    
    /**
     * Get magnet attraction radius
     */
    public float getMagnetRadius() {
        return hasMagnet ? 200.0f : 0.0f;
    }
    
    /**
     * Reset player state
     */
    public void reset(float x, float y) {
        this.x = x;
        this.y = y;
        this.velocityX = 0;
        this.velocityY = 0;
        this.lives = MAX_LIVES;
        this.isJumping = false;
        this.isInvulnerable = false;
        this.invulnerabilityTimer = 0;
        this.speedBoostTimer = 0;
        this.magnetTimer = 0;
        this.hasSpeedBoost = false;
        this.hasMagnet = false;
        this.currentFrame = 0;
        this.frameTimer = 0;
        updateCollisionBox();
    }
}
