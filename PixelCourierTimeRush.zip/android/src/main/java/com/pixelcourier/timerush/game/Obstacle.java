package com.pixelcourier.timerush.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Implementation of obstacles for Pixel Courier: Time Rush
 * Extends the GameObject class with specific obstacle behavior
 */
public class Obstacle extends GameObject {
    // Obstacle types
    public static final int TYPE_CONE = 0;
    public static final int TYPE_BOX = 1;
    public static final int TYPE_PUDDLE = 2;
    public static final int TYPE_TRASH = 3;
    
    // Obstacle properties
    private int type;
    private float speed;
    
    // References
    private AssetManager assetManager;
    
    public Obstacle(float x, float y, float width, float height, int type, float speed, AssetManager assetManager) {
        super(x, y, width, height);
        this.type = type;
        this.speed = speed;
        this.assetManager = assetManager;
        this.velocityX = -speed; // Move left
    }
    
    @Override
    public void update(float deltaTime) {
        // Update position based on velocity
        x += velocityX * deltaTime;
        
        // Update collision box
        updateCollisionBox();
    }
    
    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        
        // Draw obstacle sprite
        assetManager.drawFrame(canvas, "obstacles", type, 
                              AssetManager.OBSTACLE_FRAME_WIDTH, 
                              AssetManager.OBSTACLE_FRAME_HEIGHT, 
                              x, y, paint);
    }
    
    /**
     * Check if obstacle is off screen
     */
    public boolean isOffScreen() {
        return x + width < 0;
    }
    
    /**
     * Get obstacle type
     */
    public int getType() {
        return type;
    }
}
