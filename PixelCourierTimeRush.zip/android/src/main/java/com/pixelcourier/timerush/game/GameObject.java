package com.pixelcourier.timerush.game;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

/**
 * Base class for all game objects in Pixel Courier: Time Rush
 */
public abstract class GameObject {
    protected float x;
    protected float y;
    protected float width;
    protected float height;
    protected float velocityX;
    protected float velocityY;
    protected boolean isActive = true;
    protected Rect collisionBox;
    protected Paint paint;

    public GameObject(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.velocityX = 0;
        this.velocityY = 0;
        this.collisionBox = new Rect((int)x, (int)y, (int)(x + width), (int)(y + height));
        this.paint = new Paint();
    }

    public abstract void update(float deltaTime);
    
    public abstract void draw(Canvas canvas);
    
    public void updateCollisionBox() {
        collisionBox.left = (int)x;
        collisionBox.top = (int)y;
        collisionBox.right = (int)(x + width);
        collisionBox.bottom = (int)(y + height);
    }
    
    public boolean isColliding(GameObject other) {
        return Rect.intersects(this.collisionBox, other.collisionBox);
    }
    
    // Getters and setters
    public float getX() { return x; }
    public void setX(float x) { this.x = x; }
    
    public float getY() { return y; }
    public void setY(float y) { this.y = y; }
    
    public float getWidth() { return width; }
    public void setWidth(float width) { this.width = width; }
    
    public float getHeight() { return height; }
    public void setHeight(float height) { this.height = height; }
    
    public float getVelocityX() { return velocityX; }
    public void setVelocityX(float velocityX) { this.velocityX = velocityX; }
    
    public float getVelocityY() { return velocityY; }
    public void setVelocityY(float velocityY) { this.velocityY = velocityY; }
    
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }
    
    public Rect getCollisionBox() { return collisionBox; }
}
