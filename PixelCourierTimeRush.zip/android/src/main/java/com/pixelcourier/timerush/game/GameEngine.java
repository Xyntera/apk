package com.pixelcourier.timerush.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import com.pixelcourier.timerush.audio.AudioManager;
import com.pixelcourier.timerush.effects.EffectsManager;
import com.pixelcourier.timerush.ui.UIManager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Main game engine for Pixel Courier: Time Rush
 * Handles game state, object management, and game logic
 */
public class GameEngine {
    // Game constants
    public static final int GAME_STATE_MENU = 0;
    public static final int GAME_STATE_PLAYING = 1;
    public static final int GAME_STATE_PAUSED = 2;
    public static final int GAME_STATE_GAME_OVER = 3;
    
    // Game variables
    private int gameState;
    private int score;
    private int highScore;
    private float gameTime;
    private float timeLimit;
    private int level;
    private Random random;
    private int currentMusic;
    
    // Screen dimensions
    private int screenWidth;
    private int screenHeight;
    
    // Game objects
    private Player player;
    private List<Obstacle> obstacles;
    private List<PowerUp> powerUps;
    private List<Coin> coins;
    
    // Level generation
    private float obstacleTimer;
    private float powerUpTimer;
    private float coinTimer;
    private float obstacleInterval;
    private float powerUpInterval;
    private float coinInterval;
    
    // Background
    private float backgroundX;
    private float parallaxX;
    private float backgroundSpeed;
    
    // References
    private AssetManager assetManager;
    private UIManager uiManager;
    private static AudioManager audioManager;
    private static EffectsManager effectsManager;
    
    /**
     * Get the audio manager
     */
    public static AudioManager getAudioManager() {
        return audioManager;
    }
    
    /**
     * Get the effects manager
     */
    public static EffectsManager getEffectsManager() {
        return effectsManager;
    }
    
    public GameEngine(int screenWidth, int screenHeight, AssetManager assetManager, AudioManager audioManager) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.assetManager = assetManager;
        this.uiManager = new UIManager(screenWidth, screenHeight, assetManager);
        GameEngine.audioManager = audioManager;
        GameEngine.effectsManager = new EffectsManager(screenWidth, screenHeight);
        this.random = new Random();
        
        // Initialize collections
        obstacles = new ArrayList<>();
        powerUps = new ArrayList<>();
        coins = new ArrayList<>();
        
        // Initialize game state
        resetGame();
        
        // Set initial game state to menu
        gameState = GAME_STATE_MENU;
    }
    
    /**
     * Reset game to initial state
     */
    public void resetGame() {
        score = 0;
        gameTime = 0;
        timeLimit = 60; // 60 seconds initial time
        level = 1;
        
        // Create player
        float playerX = 100;
        float playerY = screenHeight / 2;
        player = new Player(playerX, playerY, 
                           AssetManager.PLAYER_FRAME_WIDTH, 
                           AssetManager.PLAYER_FRAME_HEIGHT, 
                           assetManager);
        
        // Clear game objects
        obstacles.clear();
        powerUps.clear();
        coins.clear();
        
        // Reset level generation timers
        obstacleTimer = 0;
        powerUpTimer = 0;
        coinTimer = 0;
        obstacleInterval = 2.0f; // 2 seconds between obstacles initially
        powerUpInterval = 10.0f; // 10 seconds between power-ups
        coinInterval = 1.0f; // 1 second between coins
        
        // Reset background
        backgroundX = 0;
        parallaxX = 0;
        backgroundSpeed = 100;
        
        // Play gameplay music
        audioManager.playMusic(AudioManager.MUSIC_GAMEPLAY);
    }
    
    /**
     * Update game state
     */
    public void update(float deltaTime) {
        // Update UI animations regardless of game state
        uiManager.update(deltaTime);
        
        // Update visual effects
        effectsManager.update(deltaTime);
        
        if (gameState == GAME_STATE_MENU) {
            // Play menu music if not already playing
            if (audioManager != null && currentMusic != AudioManager.MUSIC_MENU) {
                audioManager.playMusic(AudioManager.MUSIC_MENU);
                currentMusic = AudioManager.MUSIC_MENU;
            }
            return;
        } else if (gameState == GAME_STATE_GAME_OVER) {
            // Play game over music if not already playing
            if (audioManager != null && currentMusic != AudioManager.MUSIC_GAME_OVER) {
                audioManager.playMusic(AudioManager.MUSIC_GAME_OVER);
                currentMusic = AudioManager.MUSIC_GAME_OVER;
            }
            return;
        } else if (gameState != GAME_STATE_PLAYING) {
            return;
        }
        
        // Make sure gameplay music is playing
        if (audioManager != null && currentMusic != AudioManager.MUSIC_GAMEPLAY) {
            audioManager.playMusic(AudioManager.MUSIC_GAMEPLAY);
            currentMusic = AudioManager.MUSIC_GAMEPLAY;
        }
        
        // Update game time
        gameTime += deltaTime;
        timeLimit -= deltaTime;
        
        // Play warning sound when time is low
        if (timeLimit <= 10 && timeLimit > 9.9f) {
            audioManager.playSound(AudioManager.SOUND_TIME_LOW);
        }
        
        // Check if time's up
        if (timeLimit <= 0) {
            gameState = GAME_STATE_GAME_OVER;
            audioManager.playSound(AudioManager.SOUND_GAME_OVER);
            if (score > highScore) {
                highScore = score;
            }
            return;
        }
        
        // Update background
        backgroundX -= backgroundSpeed * deltaTime;
        if (backgroundX <= -screenWidth) {
            backgroundX += screenWidth;
        }
        
        // Update parallax background (slower)
        parallaxX -= (backgroundSpeed * 0.6f) * deltaTime;
        if (parallaxX <= -screenWidth) {
            parallaxX += screenWidth;
        }
        
        // Update player
        player.update(deltaTime);
        
        // Update obstacles
        updateObstacles(deltaTime);
        
        // Update power-ups
        updatePowerUps(deltaTime);
        
        // Update coins
        updateCoins(deltaTime);
        
        // Generate new objects
        generateGameObjects(deltaTime);
        
        // Increase difficulty over time
        if (gameTime > level * 20) { // Every 20 seconds
            level++;
            obstacleInterval = Math.max(0.5f, obstacleInterval - 0.2f);
            backgroundSpeed += 20;
        }
    }
    
    /**
     * Update obstacles and check collisions
     */
    private void updateObstacles(float deltaTime) {
        Iterator<Obstacle> iterator = obstacles.iterator();
        while (iterator.hasNext()) {
            Obstacle obstacle = iterator.next();
            obstacle.update(deltaTime);
            
            // Check collision with player
            if (player.isColliding(obstacle)) {
                // Handle collision
                if (player.hitObstacle()) {
                    // Apply penalty
                    timeLimit -= 5; // 5 seconds penalty
                    // Play crash sound
                    audioManager.playSound(AudioManager.SOUND_CRASH);
                    // Create collision visual effect
                    effectsManager.createCollisionEffect(player.getX(), player.getY());
                }
            }
            
            // Remove if off screen
            if (obstacle.isOffScreen()) {
                iterator.remove();
            }
        }
    }
    
    /**
     * Update power-ups and check collisions
     */
    private void updatePowerUps(float deltaTime) {
        Iterator<PowerUp> iterator = powerUps.iterator();
        while (iterator.hasNext()) {
            PowerUp powerUp = iterator.next();
            powerUp.update(deltaTime);
            
            // Check collision with player
            if (player.isColliding(powerUp)) {
                // Apply power-up effect
                applyPowerUp(powerUp.getType());
                iterator.remove();
                // Play power-up sound
                audioManager.playSound(AudioManager.SOUND_POWERUP);
                // Create power-up visual effect
                effectsManager.createPowerUpEffect(powerUp.getX(), powerUp.getY(), powerUp.getType());
            }
            
            // Remove if off screen
            if (powerUp.isOffScreen()) {
                iterator.remove();
            }
        }
    }
    
    /**
     * Update coins and check collisions
     */
    private void updateCoins(float deltaTime) {
        Iterator<Coin> iterator = coins.iterator();
        while (iterator.hasNext()) {
            Coin coin = iterator.next();
            
            // Check if coin should be attracted to player
            if (player.hasMagnet()) {
                float magnetRadius = player.getMagnetRadius();
                float dx = player.getX() + player.getWidth() / 2 - (coin.getX() + coin.getWidth() / 2);
                float dy = player.getY() + player.getHeight() / 2 - (coin.getY() + coin.getHeight() / 2);
                float distanceSquared = dx * dx + dy * dy;
                
                if (distanceSquared <= magnetRadius * magnetRadius) {
                    coin.attractTowards(
                        player.getX() + player.getWidth() / 2,
                        player.getY() + player.getHeight() / 2,
                        0.5f
                    );
                } else {
                    coin.stopAttracting();
                }
            } else {
                coin.stopAttracting();
            }
            
            coin.update(deltaTime);
            
            // Check collision with player
            if (player.isColliding(coin)) {
                // Collect coin
                score += coin.getValue();
                iterator.remove();
                // Play coin sound
                audioManager.playSound(AudioManager.SOUND_COIN);
                // Create coin collection visual effect
                effectsManager.createCoinEffect(coin.getX(), coin.getY());
            }
            
            // Remove if off screen
            if (coin.isOffScreen()) {
                iterator.remove();
            }
        }
    }
    
    /**
     * Apply power-up effect
     */
    private void applyPowerUp(int type) {
        switch (type) {
            case PowerUp.TYPE_CLOCK:
                // Add time
                timeLimit += 10; // 10 seconds extra time
                break;
            default:
                // Other power-ups are handled by the player
                player.applyPowerUp(type);
                break;
        }
    }
    
    /**
     * Generate new game objects
     */
    private void generateGameObjects(float deltaTime) {
        // Generate obstacles
        obstacleTimer += deltaTime;
        if (obstacleTimer >= obstacleInterval) {
            obstacleTimer = 0;
            
            // Random obstacle type
            int type = random.nextInt(Obstacle.TYPE_TRASH + 1);
            
            // Random y position
            float y = screenHeight - AssetManager.OBSTACLE_FRAME_HEIGHT - 10 - random.nextInt(100);
            
            // Create obstacle
            Obstacle obstacle = new Obstacle(
                screenWidth,
                y,
                AssetManager.OBSTACLE_FRAME_WIDTH,
                AssetManager.OBSTACLE_FRAME_HEIGHT,
                type,
                backgroundSpeed,
                assetManager
            );
            
            obstacles.add(obstacle);
        }
        
        // Generate power-ups
        powerUpTimer += deltaTime;
        if (powerUpTimer >= powerUpInterval) {
            powerUpTimer = 0;
            
            // Random power-up type
            int type = random.nextInt(PowerUp.TYPE_MAGNET + 1);
            
            // Random y position
            float y = 100 + random.nextInt(screenHeight - 200);
            
            // Create power-up
            PowerUp powerUp = new PowerUp(
                screenWidth,
                y,
                AssetManager.POWERUP_FRAME_WIDTH,
                AssetManager.POWERUP_FRAME_HEIGHT,
                type,
                backgroundSpeed,
                assetManager
            );
            
            powerUps.add(powerUp);
        }
        
        // Generate coins
        coinTimer += deltaTime;
        if (coinTimer >= coinInterval) {
            coinTimer = 0;
            
            // Random y position
            float y = 100 + random.nextInt(screenHeight - 200);
            
            // Create coin
            Coin coin = new Coin(
                screenWidth,
                y,
                AssetManager.COIN_FRAME_WIDTH,
                AssetManager.COIN_FRAME_HEIGHT,
                backgroundSpeed,
                10, // Value
                assetManager
            );
            
            coins.add(coin);
            
            // Sometimes create a line of coins
            if (random.nextFloat() < 0.2f) {
                for (int i = 1; i <= 5; i++) {
                    Coin extraCoin = new Coin(
                        screenWidth + i * 40,
                        y,
                        AssetManager.COIN_FRAME_WIDTH,
                        AssetManager.COIN_FRAME_HEIGHT,
                        backgroundSpeed,
                        10, // Value
                        assetManager
                    );
                    
                    coins.add(extraCoin);
                }
            }
        }
    }
    
    /**
     * Draw the game
     */
    public void draw(Canvas canvas) {
        // Draw background
        Paint paint = new Paint();
        
        // Draw background
        Rect srcBackground = new Rect(0, 0, screenWidth, screenHeight);
        Rect dstBackground1 = new Rect((int)backgroundX, 0, (int)(backgroundX + screenWidth), screenHeight);
        Rect dstBackground2 = new Rect((int)(backgroundX + screenWidth), 0, (int)(backgroundX + screenWidth * 2), screenHeight);
        
        canvas.drawBitmap(assetManager.getSprite("background"), srcBackground, dstBackground1, paint);
        canvas.drawBitmap(assetManager.getSprite("background"), srcBackground, dstBackground2, paint);
        
        // Draw parallax background
        Rect srcParallax = new Rect(0, 0, screenWidth, screenHeight);
        Rect dstParallax1 = new Rect((int)parallaxX, 0, (int)(parallaxX + screenWidth), screenHeight);
        Rect dstParallax2 = new Rect((int)(parallaxX + screenWidth), 0, (int)(parallaxX + screenWidth * 2), screenHeight);
        
        canvas.drawBitmap(assetManager.getSprite("parallax"), srcParallax, dstParallax1, paint);
        canvas.drawBitmap(assetManager.getSprite("parallax"), srcParallax, dstParallax2, paint);
        
        if (gameState == GAME_STATE_MENU) {
            // Draw menu using UIManager
            uiManager.drawMainMenu(canvas);
        } else if (gameState == GAME_STATE_PLAYING || gameState == GAME_STATE_PAUSED) {
            // Draw game objects
            drawGame(canvas);
            
            if (gameState == GAME_STATE_PAUSED) {
                // Draw pause overlay using UIManager
                uiManager.drawPauseOverlay(canvas);
            }
        } else if (gameState == GAME_STATE_GAME_OVER) {
            // Draw game over screen using UIManager
            uiManager.drawGameOver(canvas, score, highScore);
        }
        
        // Draw visual effects
        effectsManager.draw(canvas);
    }
    
    /**
     * Draw the game screen
     */
    private void drawGame(Canvas canvas) {
        // Draw coins
        for (Coin coin : coins) {
            coin.draw(canvas);
        }
        
        // Draw power-ups
        for (PowerUp powerUp : powerUps) {
            powerUp.draw(canvas);
        }
        
        // Draw obstacles
        for (Obstacle obstacle : obstacles) {
            obstacle.draw(canvas);
        }
        
        // Draw player
        player.draw(canvas);
        
        // Draw HUD using UIManager
        uiManager.drawHUD(canvas, score, timeLimit, player.getLives());
    }
    
    /**
     * Handle touch input
     */
    public void handleTouch(float touchX, float touchY) {
        if (gameState == GAME_STATE_MENU) {
            // Check if start button is pressed using UIManager
            if (uiManager.isStartButtonPressed(touchX, touchY)) {
                // Start game
                resetGame();
                gameState = GAME_STATE_PLAYING;
            }
        } else if (gameState == GAME_STATE_PLAYING) {
            // Check if pause button is pressed using UIManager
            if (uiManager.isPauseButtonPressed(touchX, touchY)) {
                // Pause game
                gameState = GAME_STATE_PAUSED;
            } else {
                // Control player
                player.handleTouch(touchX, touchY);
            }
        } else if (gameState == GAME_STATE_PAUSED) {
            // Check if resume button is pressed using UIManager
            if (uiManager.isResumeButtonPressed(touchX, touchY)) {
                // Resume game
                gameState = GAME_STATE_PLAYING;
            }
        } else if (gameState == GAME_STATE_GAME_OVER) {
            // Check if restart button is pressed using UIManager
            if (uiManager.isRestartButtonPressed(touchX, touchY)) {
                // Restart game
                resetGame();
                gameState = GAME_STATE_PLAYING;
            }
        }
    }
    
    /**
     * Get current game state
     */
    public int getGameState() {
        return gameState;
    }
    
    /**
     * Set game state
     */
    public void setGameState(int gameState) {
        this.gameState = gameState;
    }
}
