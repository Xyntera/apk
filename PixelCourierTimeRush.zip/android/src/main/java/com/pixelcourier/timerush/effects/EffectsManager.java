package com.pixelcourier.timerush.effects;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Visual Effects Manager for Pixel Courier: Time Rush
 * Handles particle effects, screen shake, and other visual feedback
 */
public class EffectsManager {
    // Screen dimensions
    private int screenWidth;
    private int screenHeight;
    
    // Particle systems
    private List<ParticleSystem> particleSystems;
    
    // Screen shake effect
    private float shakeTime;
    private float shakeMagnitude;
    private Random random;
    
    // Flash effect
    private float flashTime;
    private int flashColor;
    private float flashAlpha;
    
    public EffectsManager(int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.particleSystems = new ArrayList<>();
        this.random = new Random();
        this.shakeTime = 0;
        this.shakeMagnitude = 0;
        this.flashTime = 0;
        this.flashColor = Color.WHITE;
        this.flashAlpha = 0;
    }
    
    /**
     * Update all effects
     */
    public void update(float deltaTime) {
        // Update particle systems
        Iterator<ParticleSystem> iterator = particleSystems.iterator();
        while (iterator.hasNext()) {
            ParticleSystem system = iterator.next();
            system.update(deltaTime);
            
            // Remove expired particle systems
            if (system.isExpired()) {
                iterator.remove();
            }
        }
        
        // Update screen shake
        if (shakeTime > 0) {
            shakeTime -= deltaTime;
            if (shakeTime < 0) {
                shakeTime = 0;
                shakeMagnitude = 0;
            }
        }
        
        // Update flash effect
        if (flashTime > 0) {
            flashTime -= deltaTime;
            flashAlpha = (flashTime / 0.5f) * 128; // Fade out over 0.5 seconds
            if (flashTime < 0) {
                flashTime = 0;
                flashAlpha = 0;
            }
        }
    }
    
    /**
     * Draw all effects
     */
    public void draw(Canvas canvas) {
        // Apply screen shake
        if (shakeTime > 0) {
            float offsetX = (random.nextFloat() * 2 - 1) * shakeMagnitude;
            float offsetY = (random.nextFloat() * 2 - 1) * shakeMagnitude;
            canvas.translate(offsetX, offsetY);
        }
        
        // Draw particle systems
        for (ParticleSystem system : particleSystems) {
            system.draw(canvas);
        }
        
        // Draw flash effect
        if (flashTime > 0) {
            Paint paint = new Paint();
            paint.setColor(flashColor);
            paint.setAlpha((int)flashAlpha);
            canvas.drawRect(0, 0, screenWidth, screenHeight, paint);
        }
        
        // Reset canvas transform if shaking
        if (shakeTime > 0) {
            canvas.restore();
            canvas.save();
        }
    }
    
    /**
     * Create a coin collection effect
     */
    public void createCoinEffect(float x, float y) {
        // Yellow sparkle particles
        ParticleSystem sparkles = new ParticleSystem(
            x, y, 
            Color.YELLOW, 
            20, // 20 particles
            0.5f, // 0.5 second duration
            5, 10, // Size range
            50, 100, // Speed range
            360 // All directions
        );
        particleSystems.add(sparkles);
        
        // Score text particle
        TextParticle scoreText = new TextParticle(
            x, y,
            "+10",
            Color.YELLOW,
            1.0f, // 1 second duration
            0, -50 // Move upward
        );
        particleSystems.add(scoreText);
    }
    
    /**
     * Create a power-up collection effect
     */
    public void createPowerUpEffect(float x, float y, int type) {
        // Determine color based on power-up type
        int color;
        String text;
        switch (type) {
            case 0: // Time power-up
                color = Color.CYAN;
                text = "+10s";
                break;
            case 1: // Speed power-up
                color = Color.GREEN;
                text = "SPEED+";
                break;
            case 2: // Shield power-up
                color = Color.BLUE;
                text = "SHIELD";
                break;
            case 3: // Magnet power-up
                color = Color.MAGENTA;
                text = "MAGNET";
                break;
            default:
                color = Color.WHITE;
                text = "POWER!";
                break;
        }
        
        // Create sparkle effect
        ParticleSystem sparkles = new ParticleSystem(
            x, y, 
            color, 
            30, // 30 particles
            1.0f, // 1 second duration
            5, 15, // Size range
            50, 150, // Speed range
            360 // All directions
        );
        particleSystems.add(sparkles);
        
        // Create text effect
        TextParticle powerUpText = new TextParticle(
            x, y,
            text,
            color,
            1.5f, // 1.5 second duration
            0, -70 // Move upward
        );
        particleSystems.add(powerUpText);
        
        // Create flash effect
        createFlash(color, 0.3f);
    }
    
    /**
     * Create an obstacle collision effect
     */
    public void createCollisionEffect(float x, float y) {
        // Red explosion particles
        ParticleSystem explosion = new ParticleSystem(
            x, y, 
            Color.RED, 
            25, // 25 particles
            0.7f, // 0.7 second duration
            5, 15, // Size range
            70, 150, // Speed range
            360 // All directions
        );
        particleSystems.add(explosion);
        
        // Create screen shake
        createScreenShake(0.3f, 10);
        
        // Create flash effect
        createFlash(Color.RED, 0.2f);
    }
    
    /**
     * Create a jump effect
     */
    public void createJumpEffect(float x, float y) {
        // Dust particles
        ParticleSystem dust = new ParticleSystem(
            x, y + 20, // Position at feet
            Color.LTGRAY, 
            15, // 15 particles
            0.4f, // 0.4 second duration
            3, 8, // Size range
            30, 70, // Speed range
            180 // Downward half-circle
        );
        particleSystems.add(dust);
    }
    
    /**
     * Create a screen shake effect
     */
    public void createScreenShake(float duration, float magnitude) {
        this.shakeTime = duration;
        this.shakeMagnitude = magnitude;
        
        // Save canvas state for restoration after shake
        // Note: This would be called in the draw method
    }
    
    /**
     * Create a screen flash effect
     */
    public void createFlash(int color, float duration) {
        this.flashColor = color;
        this.flashTime = duration;
        this.flashAlpha = 128; // Start at 50% opacity
    }
    
    /**
     * Base class for particle systems
     */
    private abstract class ParticleSystem {
        protected float x;
        protected float y;
        protected float duration;
        protected float timeRemaining;
        
        public ParticleSystem(float x, float y, float duration) {
            this.x = x;
            this.y = y;
            this.duration = duration;
            this.timeRemaining = duration;
        }
        
        public abstract void update(float deltaTime);
        public abstract void draw(Canvas canvas);
        
        public boolean isExpired() {
            return timeRemaining <= 0;
        }
    }
    
    /**
     * Standard particle system with multiple particles
     */
    private class ParticleSystem extends ParticleSystem {
        private List<Particle> particles;
        private int color;
        
        public ParticleSystem(float x, float y, int color, int count, float duration, 
                             float minSize, float maxSize, float minSpeed, float maxSpeed, 
                             float spreadAngle) {
            super(x, y, duration);
            this.color = color;
            this.particles = new ArrayList<>();
            
            // Create particles
            for (int i = 0; i < count; i++) {
                // Calculate random angle within spread
                float angle = (random.nextFloat() * spreadAngle) - (spreadAngle / 2) + 270;
                float radians = (float) Math.toRadians(angle);
                
                // Calculate random speed
                float speed = minSpeed + random.nextFloat() * (maxSpeed - minSpeed);
                
                // Calculate velocity components
                float vx = (float) Math.cos(radians) * speed;
                float vy = (float) Math.sin(radians) * speed;
                
                // Calculate random size
                float size = minSize + random.nextFloat() * (maxSize - minSize);
                
                // Create particle
                particles.add(new Particle(x, y, vx, vy, size, color));
            }
        }
        
        @Override
        public void update(float deltaTime) {
            timeRemaining -= deltaTime;
            
            // Update particles
            for (Particle particle : particles) {
                particle.update(deltaTime);
                
                // Apply fade based on remaining time
                float alpha = timeRemaining / duration;
                particle.setAlpha(alpha);
            }
        }
        
        @Override
        public void draw(Canvas canvas) {
            for (Particle particle : particles) {
                particle.draw(canvas);
            }
        }
    }
    
    /**
     * Individual particle
     */
    private class Particle {
        private float x;
        private float y;
        private float vx;
        private float vy;
        private float size;
        private int color;
        private float alpha;
        
        public Particle(float x, float y, float vx, float vy, float size, int color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.size = size;
            this.color = color;
            this.alpha = 1.0f;
        }
        
        public void update(float deltaTime) {
            x += vx * deltaTime;
            y += vy * deltaTime;
            
            // Apply gravity
            vy += 50 * deltaTime;
            
            // Slow down over time
            vx *= 0.95f;
            vy *= 0.95f;
        }
        
        public void draw(Canvas canvas) {
            Paint paint = new Paint();
            paint.setColor(color);
            paint.setAlpha((int)(alpha * 255));
            
            canvas.drawCircle(x, y, size, paint);
        }
        
        public void setAlpha(float alpha) {
            this.alpha = alpha;
        }
    }
    
    /**
     * Text particle for score and power-up indicators
     */
    private class TextParticle extends ParticleSystem {
        private String text;
        private int color;
        private float vx;
        private float vy;
        private float alpha;
        private float scale;
        
        public TextParticle(float x, float y, String text, int color, float duration, float vx, float vy) {
            super(x, y, duration);
            this.text = text;
            this.color = color;
            this.vx = vx;
            this.vy = vy;
            this.alpha = 1.0f;
            this.scale = 1.0f;
        }
        
        @Override
        public void update(float deltaTime) {
            timeRemaining -= deltaTime;
            
            // Move text
            x += vx * deltaTime;
            y += vy * deltaTime;
            
            // Fade out over time
            alpha = timeRemaining / duration;
            
            // Scale up slightly
            scale = 1.0f + (1.0f - alpha) * 0.5f;
        }
        
        @Override
        public void draw(Canvas canvas) {
            Paint paint = new Paint();
            paint.setColor(color);
            paint.setAlpha((int)(alpha * 255));
            paint.setTextSize(30 * scale);
            paint.setTextAlign(Paint.Align.CENTER);
            
            canvas.drawText(text, x, y, paint);
        }
    }
}
