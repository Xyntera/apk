package com.pixelcourier.timerush.game;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Implementation of coins for Pixel Courier: Time Rush
 * Extends the GameObject class with specific coin behavior
 */
public class Coin extends GameObject {
    // Coin properties
    private float speed;
    private int value;
    private boolean isAttracting;
    private float attractSpeed;
    
    // Animation
    private int currentFrame;
    private float frameTimer;
    private static final float FRAME_DURATION = 0.1f; // seconds per frame
    
    // References
    private AssetManager assetManager;
    
    public Coin(float x, float y, float width, float height, float speed, int value, AssetManager assetManager) {
        super(x, y, width, height);
        this.speed = speed;
        this.value = value;
        this.assetManager = assetManager;
        this.velocityX = -speed; // Move left
        this.isAttracting = false;
        this.attractSpeed = 0;
        this.currentFrame = 0;
        this.frameTimer = 0;
    }
    
    @Override
    public void update(float deltaTime) {
        // Update position based on velocity
        x += velocityX * deltaTime;
        y += velocityY * deltaTime;
        
        // Update animation
        frameTimer += deltaTime;
        if (frameTimer >= FRAME_DURATION) {
            frameTimer = 0;
            currentFrame = (currentFrame + 1) % AssetManager.COIN_FRAME_COUNT;
        }
        
        // Update collision box
        updateCollisionBox();
    }
    
    @Override
    public void draw(Canvas canvas) {
        Paint paint = new Paint();
        
        // Draw coin sprite
        assetManager.drawFrame(canvas, "coins", currentFrame, 
                              AssetManager.COIN_FRAME_WIDTH, 
                              AssetManager.COIN_FRAME_HEIGHT, 
                              x, y, paint);
    }
    
    /**
     * Check if coin is off screen
     */
    public boolean isOffScreen() {
        return x + width < 0;
    }
    
    /**
     * Get coin value
     */
    public int getValue() {
        return value;
    }
    
    /**
     * Attract coin towards player
     */
    public void attractTowards(float targetX, float targetY, float strength) {
        isAttracting = true;
        
        // Calculate direction to player
        float dx = targetX - x;
        float dy = targetY - y;
        float distance = (float) Math.sqrt(dx * dx + dy * dy);
        
        // Normalize and apply attraction strength
        if (distance > 0) {
            attractSpeed = Math.min(attractSpeed + strength * 10, strength * 100);
            velocityX = dx / distance * attractSpeed;
            velocityY = dy / distance * attractSpeed;
        }
    }
    
    /**
     * Stop attracting coin
     */
    public void stopAttracting() {
        if (isAttracting) {
            isAttracting = false;
            velocityX = -speed;
            velocityY = 0;
            attractSpeed = 0;
        }
    }
}
