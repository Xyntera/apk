package com.pixelcourier.timerush;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;

import com.pixelcourier.timerush.game.AssetManager;
import com.pixelcourier.timerush.game.GameEngine;

public class MainActivity extends Activity {

    private GameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Set fullscreen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, 
                            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        gameView = new GameView(this);
        setContentView(gameView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameView.resume();
    }

    // Game View class - handles rendering and game loop
    class GameView extends SurfaceView implements Runnable {
        private Thread gameThread;
        private SurfaceHolder holder;
        private volatile boolean playing;
        private Canvas canvas;
        private Paint paint;
        private long fps;
        private long timeThisFrame;
        
        // Screen dimensions
        private int screenWidth;
        private int screenHeight;
        
        // Game components
        private AssetManager assetManager;
        private GameEngine gameEngine;

        public GameView(Context context) {
            super(context);
            holder = getHolder();
            paint = new Paint();
            
            // Get screen dimensions
            screenWidth = getResources().getDisplayMetrics().widthPixels;
            screenHeight = getResources().getDisplayMetrics().heightPixels;
            
            // Initialize asset manager
            assetManager = new AssetManager(context);
            
            // Initialize game engine
            gameEngine = new GameEngine(screenWidth, screenHeight, assetManager);
        }

        @Override
        public void run() {
            while (playing) {
                long startFrameTime = System.currentTimeMillis();
                
                update();
                draw();
                
                timeThisFrame = System.currentTimeMillis() - startFrameTime;
                if (timeThisFrame > 0) {
                    fps = 1000 / timeThisFrame;
                }
            }
        }

        private void update() {
            // Update game state
            float deltaTime = 1.0f / Math.max(30, fps); // Cap at 30 FPS minimum
            gameEngine.update(deltaTime);
        }

        private void draw() {
            if (holder.getSurface().isValid()) {
                canvas = holder.lockCanvas();
                
                // Clear the screen
                canvas.drawColor(Color.BLACK);
                
                // Draw game
                gameEngine.draw(canvas);
                
                // Draw FPS for debugging (can be removed in final version)
                paint.setColor(Color.WHITE);
                paint.setTextSize(30);
                canvas.drawText("FPS: " + fps, 20, screenHeight - 40, paint);
                
                holder.unlockCanvasAndPost(canvas);
            }
        }

        public void pause() {
            playing = false;
            try {
                gameThread.join();
            } catch (InterruptedException e) {
                // Error handling
            }
            
            // Save game state if needed
        }

        public void resume() {
            playing = true;
            gameThread = new Thread(this);
            gameThread.start();
            
            // Load assets
            assetManager.loadAssets();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            switch (event.getAction() & MotionEvent.ACTION_MASK) {
                case MotionEvent.ACTION_DOWN:
                    // Handle touch down event
                    gameEngine.handleTouch(event.getX(), event.getY());
                    break;
                case MotionEvent.ACTION_MOVE:
                    // Handle touch move event if needed
                    break;
                case MotionEvent.ACTION_UP:
                    // Handle touch up event if needed
                    break;
            }
            return true;
        }
    }
}
