package com.pixelcourier.timerush.game;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Manages loading and accessing game assets
 */
public class AssetManager {
    private static final String TAG = "AssetManager";
    
    private Context context;
    private android.content.res.AssetManager androidAssetManager;
    private Map<String, Bitmap> sprites;
    
    // Asset paths
    private static final String PLAYER_SPRITE_PATH = "sprites/player/player_spritesheet.png";
    private static final String OBSTACLES_SPRITE_PATH = "sprites/obstacles/obstacles_spritesheet.png";
    private static final String POWERUPS_SPRITE_PATH = "sprites/powerups/powerups_spritesheet.png";
    private static final String COINS_SPRITE_PATH = "sprites/coins/coins_spritesheet.png";
    private static final String BACKGROUND_PATH = "sprites/backgrounds/city_background.png";
    private static final String PARALLAX_PATH = "sprites/backgrounds/parallax_buildings.png";
    
    // UI elements
    private static final String UI_START_BUTTON = "sprites/ui/start_button.png";
    private static final String UI_PAUSE_BUTTON = "sprites/ui/pause_button.png";
    private static final String UI_RESUME_BUTTON = "sprites/ui/resume_button.png";
    private static final String UI_RESTART_BUTTON = "sprites/ui/restart_button.png";
    private static final String UI_TIMER_ICON = "sprites/ui/timer_icon.png";
    private static final String UI_SCORE_ICON = "sprites/ui/score_icon.png";
    private static final String UI_LIFE_ICON = "sprites/ui/life_icon.png";
    private static final String UI_TITLE_LOGO = "sprites/ui/title_logo.png";
    
    // Sprite dimensions
    public static final int PLAYER_FRAME_WIDTH = 32 * 2;  // Scaled by 2
    public static final int PLAYER_FRAME_HEIGHT = 32 * 2;
    public static final int PLAYER_FRAME_COUNT = 4;
    
    public static final int OBSTACLE_FRAME_WIDTH = 32 * 2;
    public static final int OBSTACLE_FRAME_HEIGHT = 32 * 2;
    public static final int OBSTACLE_TYPES = 4;
    
    public static final int POWERUP_FRAME_WIDTH = 24 * 2;
    public static final int POWERUP_FRAME_HEIGHT = 24 * 2;
    public static final int POWERUP_TYPES = 4;
    
    public static final int COIN_FRAME_WIDTH = 16 * 2;
    public static final int COIN_FRAME_HEIGHT = 16 * 2;
    public static final int COIN_FRAME_COUNT = 6;
    
    public AssetManager(Context context) {
        this.context = context;
        this.androidAssetManager = context.getAssets();
        this.sprites = new HashMap<>();
    }
    
    /**
     * Load all game assets
     */
    public void loadAssets() {
        loadSprite(PLAYER_SPRITE_PATH, "player");
        loadSprite(OBSTACLES_SPRITE_PATH, "obstacles");
        loadSprite(POWERUPS_SPRITE_PATH, "powerups");
        loadSprite(COINS_SPRITE_PATH, "coins");
        loadSprite(BACKGROUND_PATH, "background");
        loadSprite(PARALLAX_PATH, "parallax");
        
        // Load UI elements
        loadSprite(UI_START_BUTTON, "ui_start");
        loadSprite(UI_PAUSE_BUTTON, "ui_pause");
        loadSprite(UI_RESUME_BUTTON, "ui_resume");
        loadSprite(UI_RESTART_BUTTON, "ui_restart");
        loadSprite(UI_TIMER_ICON, "ui_timer");
        loadSprite(UI_SCORE_ICON, "ui_score");
        loadSprite(UI_LIFE_ICON, "ui_life");
        loadSprite(UI_TITLE_LOGO, "ui_title");
    }
    
    /**
     * Load a sprite from assets
     */
    private void loadSprite(String path, String key) {
        try {
            InputStream is = androidAssetManager.open(path);
            Bitmap bitmap = BitmapFactory.decodeStream(is);
            sprites.put(key, bitmap);
            is.close();
        } catch (IOException e) {
            Log.e(TAG, "Error loading sprite: " + path, e);
        }
    }
    
    /**
     * Get a sprite by key
     */
    public Bitmap getSprite(String key) {
        return sprites.get(key);
    }
    
    /**
     * Get a frame from a sprite sheet
     */
    public Bitmap getFrame(String key, int frameIndex, int frameWidth, int frameHeight) {
        Bitmap spriteSheet = sprites.get(key);
        if (spriteSheet == null) {
            return null;
        }
        
        int x = frameIndex * frameWidth;
        int y = 0;
        
        // Create a new bitmap with just the frame
        Bitmap frame = Bitmap.createBitmap(spriteSheet, x, y, frameWidth, frameHeight);
        return frame;
    }
    
    /**
     * Draw a frame from a sprite sheet
     */
    public void drawFrame(Canvas canvas, String key, int frameIndex, int frameWidth, int frameHeight, 
                         float x, float y, Paint paint) {
        Bitmap spriteSheet = sprites.get(key);
        if (spriteSheet == null) {
            return;
        }
        
        int srcX = frameIndex * frameWidth;
        int srcY = 0;
        
        Rect src = new Rect(srcX, srcY, srcX + frameWidth, srcY + frameHeight);
        Rect dst = new Rect((int)x, (int)y, (int)(x + frameWidth), (int)(y + frameHeight));
        
        canvas.drawBitmap(spriteSheet, src, dst, paint);
    }
    
    /**
     * Release all assets
     */
    public void releaseAssets() {
        for (Bitmap bitmap : sprites.values()) {
            bitmap.recycle();
        }
        sprites.clear();
    }
}
