package com.pixelcourier.timerush.ui;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Bitmap;

import com.pixelcourier.timerush.game.AssetManager;

/**
 * UI Manager for Pixel Courier: Time Rush
 * Handles UI rendering and animations for menus and in-game HUD
 */
public class UIManager {
    // Screen dimensions
    private int screenWidth;
    private int screenHeight;
    
    // UI elements
    private Button startButton;
    private Button pauseButton;
    private Button resumeButton;
    private Button restartButton;
    
    // UI animations
    private float titlePulseScale;
    private float titlePulseDirection;
    private float buttonHoverAlpha;
    
    // References
    private AssetManager assetManager;
    
    public UIManager(int screenWidth, int screenHeight, AssetManager assetManager) {
        this.screenWidth = screenWidth;
        this.screenHeight = screenHeight;
        this.assetManager = assetManager;
        
        // Initialize UI animations
        titlePulseScale = 1.0f;
        titlePulseDirection = 0.001f;
        buttonHoverAlpha = 0;
        
        // Create buttons
        createButtons();
    }
    
    /**
     * Create UI buttons
     */
    private void createButtons() {
        // Get button bitmaps
        Bitmap startBitmap = assetManager.getSprite("ui_start");
        Bitmap pauseBitmap = assetManager.getSprite("ui_pause");
        Bitmap resumeBitmap = assetManager.getSprite("ui_resume");
        Bitmap restartBitmap = assetManager.getSprite("ui_restart");
        
        // Create buttons with positions
        startButton = new Button(
            (screenWidth - startBitmap.getWidth()) / 2,
            300,
            startBitmap.getWidth(),
            startBitmap.getHeight(),
            "ui_start"
        );
        
        pauseButton = new Button(
            screenWidth - pauseBitmap.getWidth() - 20,
            screenHeight - pauseBitmap.getHeight() - 20,
            pauseBitmap.getWidth(),
            pauseBitmap.getHeight(),
            "ui_pause"
        );
        
        resumeButton = new Button(
            (screenWidth - resumeBitmap.getWidth()) / 2,
            screenHeight / 2 + 50,
            resumeBitmap.getWidth(),
            resumeBitmap.getHeight(),
            "ui_resume"
        );
        
        restartButton = new Button(
            (screenWidth - restartBitmap.getWidth()) / 2,
            screenHeight / 2 + 50,
            restartBitmap.getWidth(),
            restartBitmap.getHeight(),
            "ui_restart"
        );
    }
    
    /**
     * Update UI animations
     */
    public void update(float deltaTime) {
        // Update title pulse animation
        titlePulseScale += titlePulseDirection * deltaTime * 60;
        if (titlePulseScale > 1.05f) {
            titlePulseScale = 1.05f;
            titlePulseDirection = -0.001f;
        } else if (titlePulseScale < 0.95f) {
            titlePulseScale = 0.95f;
            titlePulseDirection = 0.001f;
        }
        
        // Update button hover animation
        buttonHoverAlpha = (float) (Math.sin(System.currentTimeMillis() / 300.0) * 0.3 + 0.7);
    }
    
    /**
     * Draw the main menu
     */
    public void drawMainMenu(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        
        // Draw title logo with pulse animation
        Bitmap titleLogo = assetManager.getSprite("ui_title");
        int titleWidth = titleLogo.getWidth();
        int titleHeight = titleLogo.getHeight();
        
        // Calculate scaled dimensions
        int scaledWidth = (int) (titleWidth * titlePulseScale);
        int scaledHeight = (int) (titleHeight * titlePulseScale);
        
        // Calculate position to keep centered
        int titleX = (screenWidth - scaledWidth) / 2;
        int titleY = 100;
        
        // Draw scaled title
        Rect src = new Rect(0, 0, titleWidth, titleHeight);
        Rect dst = new Rect(titleX, titleY, titleX + scaledWidth, titleY + scaledHeight);
        canvas.drawBitmap(titleLogo, src, dst, paint);
        
        // Draw start button with hover effect
        paint.setAlpha((int) (buttonHoverAlpha * 255));
        canvas.drawBitmap(assetManager.getSprite(startButton.getSpriteName()), 
                         startButton.getX(), startButton.getY(), paint);
        
        // Reset alpha
        paint.setAlpha(255);
        
        // Draw high score
        paint.setTextSize(40);
        String highScoreText = "High Score: " + 0; // Replace with actual high score
        float textWidth = paint.measureText(highScoreText);
        canvas.drawText(highScoreText, (screenWidth - textWidth) / 2, 500, paint);
        
        // Draw game instructions
        paint.setTextSize(30);
        String instructionsText = "Tap to jump, collect coins, avoid obstacles!";
        textWidth = paint.measureText(instructionsText);
        canvas.drawText(instructionsText, (screenWidth - textWidth) / 2, 550, paint);
    }
    
    /**
     * Draw the HUD (Heads-Up Display)
     */
    public void drawHUD(Canvas canvas, int score, float timeLimit, int lives) {
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(30);
        
        // Draw score
        Bitmap scoreIcon = assetManager.getSprite("ui_score");
        canvas.drawBitmap(scoreIcon, 20, 20, paint);
        canvas.drawText(": " + score, 20 + scoreIcon.getWidth() + 10, 20 + scoreIcon.getHeight() / 2 + 10, paint);
        
        // Draw time with color change when low
        Bitmap timerIcon = assetManager.getSprite("ui_timer");
        canvas.drawBitmap(timerIcon, screenWidth - timerIcon.getWidth() - 150, 20, paint);
        
        // Change color based on time remaining
        if (timeLimit <= 10) {
            // Flash red when time is low
            int alpha = (int) (Math.sin(System.currentTimeMillis() / 100.0) * 127 + 128);
            paint.setColor(Color.argb(alpha, 255, 0, 0));
        } else if (timeLimit <= 30) {
            paint.setColor(Color.YELLOW);
        }
        
        canvas.drawText(": " + (int)timeLimit, screenWidth - 150 + 10, 20 + timerIcon.getHeight() / 2 + 10, paint);
        
        // Reset color
        paint.setColor(Color.WHITE);
        
        // Draw lives
        Bitmap lifeIcon = assetManager.getSprite("ui_life");
        for (int i = 0; i < lives; i++) {
            canvas.drawBitmap(lifeIcon, screenWidth - lifeIcon.getWidth() * (i + 1) - 20, 20 + timerIcon.getHeight() + 20, paint);
        }
        
        // Draw pause button
        canvas.drawBitmap(assetManager.getSprite(pauseButton.getSpriteName()), 
                         pauseButton.getX(), pauseButton.getY(), paint);
    }
    
    /**
     * Draw the pause overlay
     */
    public void drawPauseOverlay(Canvas canvas) {
        Paint paint = new Paint();
        paint.setColor(Color.argb(128, 0, 0, 0));
        canvas.drawRect(0, 0, screenWidth, screenHeight, paint);
        
        paint.setColor(Color.WHITE);
        paint.setTextSize(60);
        String pausedText = "PAUSED";
        float textWidth = paint.measureText(pausedText);
        canvas.drawText(pausedText, (screenWidth - textWidth) / 2, screenHeight / 2 - 50, paint);
        
        // Draw resume button with hover effect
        paint.setAlpha((int) (buttonHoverAlpha * 255));
        canvas.drawBitmap(assetManager.getSprite(resumeButton.getSpriteName()), 
                         resumeButton.getX(), resumeButton.getY(), paint);
        
        // Reset alpha
        paint.setAlpha(255);
    }
    
    /**
     * Draw the game over screen
     */
    public void drawGameOver(Canvas canvas, int score, int highScore) {
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);
        paint.setTextSize(60);
        
        String gameOverText = "GAME OVER";
        float textWidth = paint.measureText(gameOverText);
        canvas.drawText(gameOverText, (screenWidth - textWidth) / 2, screenHeight / 2 - 100, paint);
        
        paint.setTextSize(40);
        String scoreText = "Score: " + score;
        textWidth = paint.measureText(scoreText);
        canvas.drawText(scoreText, (screenWidth - textWidth) / 2, screenHeight / 2, paint);
        
        // Show high score if achieved
        if (score >= highScore && highScore > 0) {
            paint.setColor(Color.YELLOW);
            String newHighScoreText = "NEW HIGH SCORE!";
            textWidth = paint.measureText(newHighScoreText);
            canvas.drawText(newHighScoreText, (screenWidth - textWidth) / 2, screenHeight / 2 + 50, paint);
            paint.setColor(Color.WHITE);
        } else if (highScore > 0) {
            String highScoreText = "High Score: " + highScore;
            textWidth = paint.measureText(highScoreText);
            canvas.drawText(highScoreText, (screenWidth - textWidth) / 2, screenHeight / 2 + 50, paint);
        }
        
        // Draw restart button with hover effect
        paint.setAlpha((int) (buttonHoverAlpha * 255));
        canvas.drawBitmap(assetManager.getSprite(restartButton.getSpriteName()), 
                         restartButton.getX(), restartButton.getY() + 50, paint);
        
        // Reset alpha
        paint.setAlpha(255);
    }
    
    /**
     * Check if start button is pressed
     */
    public boolean isStartButtonPressed(float touchX, float touchY) {
        return startButton.isPressed(touchX, touchY);
    }
    
    /**
     * Check if pause button is pressed
     */
    public boolean isPauseButtonPressed(float touchX, float touchY) {
        return pauseButton.isPressed(touchX, touchY);
    }
    
    /**
     * Check if resume button is pressed
     */
    public boolean isResumeButtonPressed(float touchX, float touchY) {
        return resumeButton.isPressed(touchX, touchY);
    }
    
    /**
     * Check if restart button is pressed
     */
    public boolean isRestartButtonPressed(float touchX, float touchY) {
        return restartButton.isPressed(touchX, touchY);
    }
    
    /**
     * Button class for UI elements
     */
    private class Button {
        private float x;
        private float y;
        private float width;
        private float height;
        private String spriteName;
        
        public Button(float x, float y, float width, float height, String spriteName) {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
            this.spriteName = spriteName;
        }
        
        public boolean isPressed(float touchX, float touchY) {
            return touchX >= x && touchX <= x + width && touchY >= y && touchY <= y + height;
        }
        
        public float getX() { return x; }
        public float getY() { return y; }
        public float getWidth() { return width; }
        public float getHeight() { return height; }
        public String getSpriteName() { return spriteName; }
    }
}
