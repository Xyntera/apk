import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
RED = (255, 0, 0, 255)
GREEN = (0, 255, 0, 255)
BLUE = (0, 0, 255, 255)
YELLOW = (255, 255, 0, 255)
GRAY = (100, 100, 100, 255)
DARK_GRAY = (50, 50, 50, 255)
LIGHT_GRAY = (200, 200, 200, 255)

# Set up dimensions
BUTTON_WIDTH = 128
BUTTON_HEIGHT = 48
ICON_SIZE = 32
SCALE = 2

def create_ui_elements():
    # Create buttons
    create_button("Start", "start_button.png")
    create_button("Pause", "pause_button.png")
    create_button("Resume", "resume_button.png")
    create_button("Restart", "restart_button.png")
    
    # Create HUD elements
    create_timer_icon()
    create_score_icon()
    create_life_icon()
    
    # Create title logo
    create_title_logo()

def create_button(text, filename):
    # Create a surface for the button
    button = np.zeros((BUTTON_HEIGHT, BUTTON_WIDTH, 4), dtype=np.uint8)
    
    # Button background
    for y in range(BUTTON_HEIGHT):
        for x in range(BUTTON_WIDTH):
            button[y, x] = BLUE
    
    # Button border
    for y in range(BUTTON_HEIGHT):
        for x in range(BUTTON_WIDTH):
            if y < 3 or y >= BUTTON_HEIGHT - 3 or x < 3 or x >= BUTTON_WIDTH - 3:
                button[y, x] = DARK_GRAY
    
    # Button highlight
    for y in range(3, 10):
        for x in range(3, BUTTON_WIDTH - 3):
            button[y, x] = LIGHT_GRAY
    
    # Convert to PIL Image to use text drawing
    button_img = Image.fromarray(button)
    
    # Scale up the image
    button_img = button_img.resize((BUTTON_WIDTH * SCALE, BUTTON_HEIGHT * SCALE), Image.NEAREST)
    
    # Save the button
    button_img.save(filename)

def create_timer_icon():
    # Create a surface for the icon
    icon = np.zeros((ICON_SIZE, ICON_SIZE, 4), dtype=np.uint8)
    
    # Clock face
    center_x, center_y = ICON_SIZE // 2, ICON_SIZE // 2
    radius = 12
    
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                    icon[y, x] = WHITE
    
    # Clock border
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if radius - 1 <= (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                    icon[y, x] = BLACK
    
    # Clock hands
    for i in range(-8, 1):
        if 0 <= center_y + i < ICON_SIZE and 0 <= center_x < ICON_SIZE:
            icon[center_y + i, center_x] = BLACK
    
    for i in range(-5, 1):
        if 0 <= center_y < ICON_SIZE and 0 <= center_x + i < ICON_SIZE:
            icon[center_y, center_x + i] = BLACK
    
    # Convert to PIL Image
    icon_img = Image.fromarray(icon)
    
    # Scale up the image
    icon_img = icon_img.resize((ICON_SIZE * SCALE, ICON_SIZE * SCALE), Image.NEAREST)
    
    # Save the icon
    icon_img.save("timer_icon.png")

def create_score_icon():
    # Create a surface for the icon
    icon = np.zeros((ICON_SIZE, ICON_SIZE, 4), dtype=np.uint8)
    
    # Coin shape
    center_x, center_y = ICON_SIZE // 2, ICON_SIZE // 2
    radius = 10
    
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                    icon[y, x] = YELLOW
    
    # Coin border
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if radius - 1 <= (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                    icon[y, x] = BLACK
    
    # Dollar sign
    for y in range(center_y - 5, center_y + 6):
        if 0 <= y < ICON_SIZE and 0 <= center_x < ICON_SIZE:
            icon[y, center_x] = BLACK
    
    for y in [center_y - 5, center_y, center_y + 5]:
        for x in range(center_x - 3, center_x + 4):
            if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                icon[y, x] = BLACK
    
    # Convert to PIL Image
    icon_img = Image.fromarray(icon)
    
    # Scale up the image
    icon_img = icon_img.resize((ICON_SIZE * SCALE, ICON_SIZE * SCALE), Image.NEAREST)
    
    # Save the icon
    icon_img.save("score_icon.png")

def create_life_icon():
    # Create a surface for the icon
    icon = np.zeros((ICON_SIZE, ICON_SIZE, 4), dtype=np.uint8)
    
    # Heart shape
    for y in range(5, 25):
        for x in range(5, 27):
            # Create heart shape using two circles and a triangle
            in_left_circle = (x - 10) ** 2 + (y - 12) ** 2 <= 5 ** 2
            in_right_circle = (x - 22) ** 2 + (y - 12) ** 2 <= 5 ** 2
            
            # Triangle for bottom part of heart
            in_triangle = (y >= 12) and (x >= 5) and (x <= 27) and (y - 12 <= 1.5 * abs(x - 16))
            
            if in_left_circle or in_right_circle or in_triangle:
                if 0 <= y < ICON_SIZE and 0 <= x < ICON_SIZE:
                    icon[y, x] = RED
    
    # Convert to PIL Image
    icon_img = Image.fromarray(icon)
    
    # Scale up the image
    icon_img = icon_img.resize((ICON_SIZE * SCALE, ICON_SIZE * SCALE), Image.NEAREST)
    
    # Save the icon
    icon_img.save("life_icon.png")

def create_title_logo():
    # Create a surface for the logo
    logo_width = 256
    logo_height = 64
    logo = np.zeros((logo_height, logo_width, 4), dtype=np.uint8)
    
    # Background
    for y in range(logo_height):
        for x in range(logo_width):
            # Create a gradient background
            logo[y, x] = (0, 0, 100 + int(155 * x / logo_width), 255)
    
    # Border
    for y in range(logo_height):
        for x in range(logo_width):
            if y < 3 or y >= logo_height - 3 or x < 3 or x >= logo_width - 3:
                logo[y, x] = YELLOW
    
    # Convert to PIL Image
    logo_img = Image.fromarray(logo)
    
    # Scale up the image
    logo_img = logo_img.resize((logo_width * SCALE, logo_height * SCALE), Image.NEAREST)
    
    # Save the logo
    logo_img.save("title_logo.png")

if __name__ == "__main__":
    create_ui_elements()
