import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
RED = (255, 0, 0, 255)
GREEN = (0, 255, 0, 255)
BLUE = (0, 0, 255, 255)
YELLOW = (255, 255, 0, 255)
PURPLE = (128, 0, 128, 255)
CYAN = (0, 255, 255, 255)
GOLD = (255, 215, 0, 255)
SILVER = (192, 192, 192, 255)

# Set up dimensions
SPRITE_WIDTH = 24
SPRITE_HEIGHT = 24
SCALE = 2
POWERUP_TYPES = 4

def create_powerup_sprites():
    # Create a surface for the sprite sheet
    sprite_sheet = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH * POWERUP_TYPES, 4), dtype=np.uint8)
    
    # Powerup 1: Clock (extra time)
    powerup_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Clock face
    center_x, center_y = SPRITE_WIDTH // 2, SPRITE_HEIGHT // 2
    radius = 8
    
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                    powerup_array[y, x] = SILVER
    
    # Clock border
    for y in range(center_y - radius, center_y + radius + 1):
        for x in range(center_x - radius, center_x + radius + 1):
            if radius - 1 <= (x - center_x) ** 2 + (y - center_y) ** 2 <= radius ** 2:
                if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                    powerup_array[y, x] = BLACK
    
    # Clock hands
    for i in range(-3, 4):
        if 0 <= center_y + i < SPRITE_HEIGHT and 0 <= center_x - 5 < SPRITE_WIDTH:
            powerup_array[center_y + i, center_x] = BLACK
    
    for i in range(-3, 1):
        if 0 <= center_y < SPRITE_HEIGHT and 0 <= center_x + i < SPRITE_WIDTH:
            powerup_array[center_y, center_x + i] = BLACK
    
    # Add to sprite sheet
    sprite_sheet[:, 0:SPRITE_WIDTH] = powerup_array
    
    # Powerup 2: Speed boost
    powerup_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Lightning bolt
    bolt_points = [
        (12, 4), (16, 4), (12, 12), (16, 12), (8, 20), (12, 12), (8, 12)
    ]
    
    # Draw filled lightning bolt
    for y in range(4, 21):
        for x in range(8, 17):
            # Simple point-in-polygon test
            inside = False
            for i in range(len(bolt_points)):
                j = (i + 1) % len(bolt_points)
                if ((bolt_points[i][1] > y) != (bolt_points[j][1] > y)) and \
                   (x < bolt_points[i][0] + (bolt_points[j][0] - bolt_points[i][0]) * (y - bolt_points[i][1]) / (bolt_points[j][1] - bolt_points[i][1])):
                    inside = not inside
            
            if inside and 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = YELLOW
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH:SPRITE_WIDTH*2] = powerup_array
    
    # Powerup 3: Shield (invincibility)
    powerup_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Shield shape
    for y in range(6, 18):
        width = int(8 * min(y - 6, 18 - y) / 6)
        for x in range(center_x - width, center_x + width + 1):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = BLUE
    
    # Shield highlight
    for y in range(7, 17):
        width = int(6 * min(y - 7, 17 - y) / 5)
        for x in range(center_x - width + 1, center_x + 1):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = CYAN
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH*2:SPRITE_WIDTH*3] = powerup_array
    
    # Powerup 4: Magnet (coin attractor)
    powerup_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Horseshoe magnet
    for y in range(8, 16):
        for x in range(6, 10):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = RED
    
    for y in range(8, 16):
        for x in range(14, 18):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = RED
    
    for y in range(16, 20):
        for x in range(6, 18):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = RED
    
    # North/South poles
    for y in range(5, 8):
        for x in range(6, 10):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = BLUE
    
    for y in range(5, 8):
        for x in range(14, 18):
            if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                powerup_array[y, x] = RED
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH*3:SPRITE_WIDTH*4] = powerup_array
    
    # Convert to PIL Image
    sprite_sheet_img = Image.fromarray(sprite_sheet)
    
    # Scale up the image
    sprite_sheet_img = sprite_sheet_img.resize((SPRITE_WIDTH * POWERUP_TYPES * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
    
    # Save the sprite sheet
    sprite_sheet_img.save('powerups_spritesheet.png')
    
    # Also create individual powerups
    for i in range(POWERUP_TYPES):
        powerup_img = Image.fromarray(sprite_sheet[:, i * SPRITE_WIDTH:(i + 1) * SPRITE_WIDTH])
        powerup_img = powerup_img.resize((SPRITE_WIDTH * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
        powerup_img.save(f'powerup{i+1}.png')

if __name__ == "__main__":
    create_powerup_sprites()
