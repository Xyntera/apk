import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
BLUE = (100, 150, 255, 255)
DARK_BLUE = (50, 100, 200, 255)
LIGHT_BLUE = (150, 200, 255, 255)
GRAY = (100, 100, 100, 255)
DARK_GRAY = (50, 50, 50, 255)
LIGHT_GRAY = (200, 200, 200, 255)
BROWN = (139, 69, 19, 255)
GREEN = (50, 200, 50, 255)

# Set up dimensions
WIDTH = 256
HEIGHT = 128
SCALE = 2

def create_background():
    # Create a surface for the background
    background = np.zeros((HEIGHT, WIDTH, 4), dtype=np.uint8)
    
    # Sky gradient
    for y in range(HEIGHT):
        # Calculate sky color based on height
        intensity = max(0, min(255, 150 + int(y * 0.5)))
        background[y, :] = (100, intensity, 255, 255)
    
    # Ground
    ground_level = HEIGHT - 30
    for y in range(ground_level, HEIGHT):
        background[y, :] = GRAY
    
    # Road
    road_width = 80
    for y in range(ground_level, HEIGHT):
        for x in range(WIDTH // 2 - road_width // 2, WIDTH // 2 + road_width // 2):
            background[y, x] = DARK_GRAY
    
    # Road markings
    for y in range(ground_level, HEIGHT):
        for x in range(WIDTH // 2 - 2, WIDTH // 2 + 2):
            if (y // 10) % 2 == 0:  # Dashed line
                background[y, x] = WHITE
    
    # Buildings in background
    for i in range(5):
        building_x = i * 50
        building_height = np.random.randint(30, 70)
        building_width = np.random.randint(30, 40)
        
        for y in range(ground_level - building_height, ground_level):
            for x in range(building_x, building_x + building_width):
                if 0 <= x < WIDTH:
                    background[y, x] = BLUE
        
        # Windows
        for wy in range(ground_level - building_height + 5, ground_level - 5, 10):
            for wx in range(building_x + 5, building_x + building_width - 5, 10):
                if 0 <= wx < WIDTH and wx + 5 < WIDTH:
                    if np.random.random() > 0.3:  # Some windows are lit
                        for y in range(wy, wy + 5):
                            for x in range(wx, wx + 5):
                                if 0 <= x < WIDTH:
                                    background[y, x] = LIGHT_YELLOW
                    else:
                        for y in range(wy, wy + 5):
                            for x in range(wx, wx + 5):
                                if 0 <= x < WIDTH:
                                    background[y, x] = DARK_BLUE
    
    # Trees
    for i in range(3):
        tree_x = np.random.randint(0, WIDTH)
        tree_height = np.random.randint(20, 40)
        
        # Trunk
        for y in range(ground_level - tree_height // 3, ground_level):
            for x in range(tree_x - 2, tree_x + 3):
                if 0 <= x < WIDTH:
                    background[y, x] = BROWN
        
        # Leaves
        for y in range(ground_level - tree_height, ground_level - tree_height // 3):
            radius = int((tree_height - (ground_level - y)) * 0.5)
            for x in range(tree_x - radius, tree_x + radius + 1):
                if 0 <= x < WIDTH and ((x - tree_x) ** 2 + (y - (ground_level - tree_height // 2)) ** 2) <= radius ** 2:
                    background[y, x] = GREEN
    
    # Convert to PIL Image
    background_img = Image.fromarray(background)
    
    # Scale up the image
    background_img = background_img.resize((WIDTH * SCALE, HEIGHT * SCALE), Image.NEAREST)
    
    # Save the background
    background_img.save('city_background.png')
    
    # Create a parallax background layer (buildings only)
    parallax = np.zeros((HEIGHT, WIDTH, 4), dtype=np.uint8)
    
    # Fill with transparent
    parallax.fill(0)
    
    # More distant buildings
    for i in range(8):
        building_x = i * 30
        building_height = np.random.randint(20, 40)
        building_width = np.random.randint(20, 25)
        
        for y in range(ground_level - building_height, ground_level):
            for x in range(building_x, building_x + building_width):
                if 0 <= x < WIDTH:
                    parallax[y, x] = DARK_BLUE
        
        # Windows
        for wy in range(ground_level - building_height + 3, ground_level - 3, 7):
            for wx in range(building_x + 3, building_x + building_width - 3, 7):
                if 0 <= wx < WIDTH and wx + 3 < WIDTH:
                    if np.random.random() > 0.5:  # Some windows are lit
                        for y in range(wy, wy + 3):
                            for x in range(wx, wx + 3):
                                if 0 <= x < WIDTH:
                                    parallax[y, x] = LIGHT_BLUE
    
    # Convert to PIL Image
    parallax_img = Image.fromarray(parallax)
    
    # Scale up the image
    parallax_img = parallax_img.resize((WIDTH * SCALE, HEIGHT * SCALE), Image.NEAREST)
    
    # Save the parallax layer
    parallax_img.save('parallax_buildings.png')

# Define additional colors
LIGHT_YELLOW = (255, 255, 150, 255)

if __name__ == "__main__":
    create_background()
