import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
GOLD = (255, 215, 0, 255)
YELLOW = (255, 255, 0, 255)
SILVER = (192, 192, 192, 255)
BRONZE = (205, 127, 50, 255)

# Set up dimensions
SPRITE_WIDTH = 16
SPRITE_HEIGHT = 16
SCALE = 2
FRAMES = 6  # Animation frames for spinning coin

def create_coin_sprites():
    # Create a surface for the sprite sheet
    sprite_sheet = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH * FRAMES, 4), dtype=np.uint8)
    
    # Create spinning coin animation
    for frame in range(FRAMES):
        coin_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
        
        # Calculate width of coin based on frame (simulating rotation)
        if frame < FRAMES // 2:
            width = max(2, int(10 * (1 - frame / (FRAMES // 2 - 1))))
        else:
            width = max(2, int(10 * ((frame - FRAMES // 2) / (FRAMES // 2))))
        
        center_x, center_y = SPRITE_WIDTH // 2, SPRITE_HEIGHT // 2
        
        # Draw coin
        for y in range(center_y - 5, center_y + 5):
            for x in range(center_x - width // 2, center_x + width // 2):
                if ((x - center_x) / (width / 2)) ** 2 + ((y - center_y) / 5) ** 2 <= 1:
                    if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                        coin_array[y, x] = GOLD
        
        # Add highlight
        if width > 4:
            for y in range(center_y - 4, center_y - 1):
                for x in range(center_x - width // 2 + 1, center_x + width // 2 - 1):
                    if ((x - center_x) / (width / 2 - 1)) ** 2 + ((y - (center_y - 3)) / 2) ** 2 <= 1:
                        if 0 <= y < SPRITE_HEIGHT and 0 <= x < SPRITE_WIDTH:
                            coin_array[y, x] = YELLOW
        
        # Add to sprite sheet
        sprite_sheet[:, frame * SPRITE_WIDTH:(frame + 1) * SPRITE_WIDTH] = coin_array
    
    # Convert to PIL Image
    sprite_sheet_img = Image.fromarray(sprite_sheet)
    
    # Scale up the image
    sprite_sheet_img = sprite_sheet_img.resize((SPRITE_WIDTH * FRAMES * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
    
    # Save the sprite sheet
    sprite_sheet_img.save('coins_spritesheet.png')
    
    # Also create individual frames
    for frame in range(FRAMES):
        frame_img = Image.fromarray(sprite_sheet[:, frame * SPRITE_WIDTH:(frame + 1) * SPRITE_WIDTH])
        frame_img = frame_img.resize((SPRITE_WIDTH * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
        frame_img.save(f'coin_frame{frame}.png')

if __name__ == "__main__":
    create_coin_sprites()
