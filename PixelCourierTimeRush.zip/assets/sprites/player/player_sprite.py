import pygame
import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
RED = (255, 0, 0, 255)
BLUE = (0, 0, 255, 255)
YELLOW = (255, 255, 0, 255)
GRAY = (100, 100, 100, 255)
LIGHT_BLUE = (100, 100, 255, 255)

# Set up dimensions
SPRITE_WIDTH = 32
SPRITE_HEIGHT = 32
SCALE = 2
FRAMES = 4

def create_player_sprite():
    # Create a surface for the sprite sheet
    sprite_sheet = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH * FRAMES, 4), dtype=np.uint8)
    
    # Base character design - a delivery courier with a package
    for frame in range(FRAMES):
        # Start with a transparent frame
        frame_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
        
        # Body (blue uniform)
        for y in range(12, 26):
            for x in range(10, 22):
                frame_array[y, x] = BLUE
        
        # Head
        for y in range(5, 12):
            for x in range(11, 21):
                frame_array[y, x] = WHITE
        
        # Face details
        frame_array[8, 14] = BLACK  # Left eye
        frame_array[8, 18] = BLACK  # Right eye
        frame_array[10, 16] = BLACK  # Mouth
        
        # Cap
        for y in range(3, 6):
            for x in range(10, 22):
                frame_array[y, x] = RED
        
        # Package
        for y in range(15, 22):
            for x in range(20, 28):
                frame_array[y, x] = YELLOW
        
        # Arms
        # Left arm
        for y in range(14, 18):
            for x in range(6, 10):
                frame_array[y, x] = WHITE
        
        # Right arm (holding package)
        for y in range(14, 18):
            for x in range(22, 26):
                frame_array[y, x] = WHITE
        
        # Legs - animate based on frame
        leg_offset = [0, 1, 0, -1][frame]  # Walking animation
        
        # Left leg
        for y in range(26, 30):
            for x in range(12, 16):
                y_pos = y + leg_offset
                if 0 <= y_pos < SPRITE_HEIGHT:
                    frame_array[y_pos, x] = GRAY
        
        # Right leg
        for y in range(26, 30):
            for x in range(16, 20):
                y_pos = y - leg_offset
                if 0 <= y_pos < SPRITE_HEIGHT:
                    frame_array[y_pos, x] = GRAY
        
        # Add frame to sprite sheet
        sprite_sheet[:, frame * SPRITE_WIDTH:(frame + 1) * SPRITE_WIDTH] = frame_array
    
    # Convert to PIL Image
    sprite_sheet_img = Image.fromarray(sprite_sheet)
    
    # Scale up the image
    sprite_sheet_img = sprite_sheet_img.resize((SPRITE_WIDTH * FRAMES * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
    
    # Save the sprite sheet
    sprite_sheet_img.save('player_spritesheet.png')
    
    # Also create individual frames
    for frame in range(FRAMES):
        frame_img = Image.fromarray(sprite_sheet[:, frame * SPRITE_WIDTH:(frame + 1) * SPRITE_WIDTH])
        frame_img = frame_img.resize((SPRITE_WIDTH * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
        frame_img.save(f'player_frame{frame}.png')

if __name__ == "__main__":
    create_player_sprite()
