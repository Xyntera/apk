import numpy as np
from PIL import Image

# Define colors
TRANSPARENT = (0, 0, 0, 0)
BLACK = (0, 0, 0, 255)
WHITE = (255, 255, 255, 255)
RED = (255, 0, 0, 255)
GREEN = (0, 255, 0, 255)
BLUE = (0, 0, 255, 255)
YELLOW = (255, 255, 0, 255)
GRAY = (100, 100, 100, 255)
BROWN = (139, 69, 19, 255)
ORANGE = (255, 165, 0, 255)

# Set up dimensions
SPRITE_WIDTH = 32
SPRITE_HEIGHT = 32
SCALE = 2
OBSTACLE_TYPES = 4

def create_obstacle_sprites():
    # Create a surface for the sprite sheet
    sprite_sheet = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH * OBSTACLE_TYPES, 4), dtype=np.uint8)
    
    # Obstacle 1: Traffic cone
    obstacle_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Orange cone
    for y in range(15, 30):
        width = int(10 * (30 - y) / 15)
        for x in range(16 - width, 16 + width):
            if 0 <= x < SPRITE_WIDTH:
                obstacle_array[y, x] = ORANGE
    
    # White stripes
    for y in range(18, 28, 3):
        width = int(8 * (30 - y) / 15)
        for x in range(16 - width, 16 + width):
            if 0 <= x < SPRITE_WIDTH:
                obstacle_array[y, x] = WHITE
    
    # Add to sprite sheet
    sprite_sheet[:, 0:SPRITE_WIDTH] = obstacle_array
    
    # Obstacle 2: Cardboard box
    obstacle_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Box
    for y in range(15, 30):
        for x in range(8, 24):
            obstacle_array[y, x] = BROWN
    
    # Box details
    for y in range(15, 30, 3):
        for x in range(8, 24):
            obstacle_array[y, x] = (BROWN[0] - 20, BROWN[1] - 10, BROWN[2] - 10, 255)
    
    for x in range(8, 24, 3):
        for y in range(15, 30):
            obstacle_array[y, x] = (BROWN[0] - 20, BROWN[1] - 10, BROWN[2] - 10, 255)
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH:SPRITE_WIDTH*2] = obstacle_array
    
    # Obstacle 3: Puddle
    obstacle_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Blue puddle
    for y in range(25, 30):
        for x in range(8, 24):
            # Create an oval shape
            if ((x - 16) / 8) ** 2 + ((y - 27) / 2) ** 2 <= 1:
                obstacle_array[y, x] = LIGHT_BLUE
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH*2:SPRITE_WIDTH*3] = obstacle_array
    
    # Obstacle 4: Trash can
    obstacle_array = np.zeros((SPRITE_HEIGHT, SPRITE_WIDTH, 4), dtype=np.uint8)
    
    # Gray trash can
    for y in range(15, 30):
        for x in range(10, 22):
            obstacle_array[y, x] = GRAY
    
    # Trash can lid
    for y in range(13, 15):
        for x in range(9, 23):
            obstacle_array[y, x] = (GRAY[0] + 50, GRAY[1] + 50, GRAY[2] + 50, 255)
    
    # Trash can details
    for y in range(18, 28, 4):
        for x in range(10, 22):
            obstacle_array[y, x] = (GRAY[0] - 30, GRAY[1] - 30, GRAY[2] - 30, 255)
    
    # Add to sprite sheet
    sprite_sheet[:, SPRITE_WIDTH*3:SPRITE_WIDTH*4] = obstacle_array
    
    # Convert to PIL Image
    sprite_sheet_img = Image.fromarray(sprite_sheet)
    
    # Scale up the image
    sprite_sheet_img = sprite_sheet_img.resize((SPRITE_WIDTH * OBSTACLE_TYPES * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
    
    # Save the sprite sheet
    sprite_sheet_img.save('obstacles_spritesheet.png')
    
    # Also create individual obstacles
    for i in range(OBSTACLE_TYPES):
        obstacle_img = Image.fromarray(sprite_sheet[:, i * SPRITE_WIDTH:(i + 1) * SPRITE_WIDTH])
        obstacle_img = obstacle_img.resize((SPRITE_WIDTH * SCALE, SPRITE_HEIGHT * SCALE), Image.NEAREST)
        obstacle_img.save(f'obstacle{i+1}.png')

# Define light blue color
LIGHT_BLUE = (100, 200, 255, 255)

if __name__ == "__main__":
    create_obstacle_sprites()
