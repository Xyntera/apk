import numpy as np
from scipy.io import wavfile
import os

# Define sound parameters
SAMPLE_RATE = 44100  # Hz
DURATION = 0.5  # seconds

def create_jump_sound():
    """Create a jump sound effect - rising tone"""
    t = np.linspace(0, DURATION, int(SAMPLE_RATE * DURATION), False)
    # Frequency rises from 300 to 1200 Hz
    frequency = np.linspace(300, 1200, int(SAMPLE_RATE * DURATION))
    # Amplitude decreases over time
    amplitude = np.linspace(1.0, 0.1, int(SAMPLE_RATE * DURATION))
    # Generate sine wave
    note = 0.5 * amplitude * np.sin(2 * np.pi * frequency * t)
    # Ensure it's in int16 range
    audio = (note * 32767).astype(np.int16)
    # Save to file
    wavfile.write('jump.wav', SAMPLE_RATE, audio)

def create_coin_sound():
    """Create a coin collection sound - short high ping"""
    t = np.linspace(0, 0.2, int(SAMPLE_RATE * 0.2), False)
    # High frequency ping
    frequency = 1800
    # Quick decay
    amplitude = np.exp(-10 * t)
    # Generate sine wave
    note = 0.5 * amplitude * np.sin(2 * np.pi * frequency * t)
    # Ensure it's in int16 range
    audio = (note * 32767).astype(np.int16)
    # Save to file
    wavfile.write('coin.wav', SAMPLE_RATE, audio)

def create_powerup_sound():
    """Create a power-up collection sound - ascending tones"""
    t = np.linspace(0, 0.4, int(SAMPLE_RATE * 0.4), False)
    # Three ascending notes
    frequencies = [523.25, 659.25, 783.99]  # C5, E5, G5
    audio = np.zeros(int(SAMPLE_RATE * 0.4), dtype=np.float64)
    
    for i, freq in enumerate(frequencies):
        # Each note starts a bit later
        start = int(i * SAMPLE_RATE * 0.1)
        end = int(SAMPLE_RATE * 0.4)
        segment_t = t[start:end]
        # Amplitude envelope
        amplitude = np.exp(-5 * (segment_t - i * 0.1 - 0.05))
        # Generate sine wave
        note = 0.3 * amplitude * np.sin(2 * np.pi * freq * segment_t)
        # Add to audio
        audio[start:end] += note
    
    # Ensure it's in int16 range
    audio = (audio * 32767).astype(np.int16)
    # Save to file
    wavfile.write('powerup.wav', SAMPLE_RATE, audio)

def create_crash_sound():
    """Create a crash sound effect - noise burst"""
    t = np.linspace(0, 0.3, int(SAMPLE_RATE * 0.3), False)
    # Random noise
    noise = np.random.uniform(-1, 1, int(SAMPLE_RATE * 0.3))
    # Quick decay
    amplitude = np.exp(-10 * t)
    # Apply envelope
    audio = amplitude * noise
    # Add a low frequency component for impact
    impact = 0.7 * amplitude * np.sin(2 * np.pi * 150 * t)
    audio += impact
    # Ensure it's in int16 range
    audio = (audio * 32767).astype(np.int16)
    # Save to file
    wavfile.write('crash.wav', SAMPLE_RATE, audio)

def create_game_over_sound():
    """Create a game over sound effect - descending tones"""
    t = np.linspace(0, 1.0, int(SAMPLE_RATE * 1.0), False)
    # Three descending notes
    frequencies = [659.25, 523.25, 392.00]  # E5, C5, G4
    audio = np.zeros(int(SAMPLE_RATE * 1.0), dtype=np.float64)
    
    for i, freq in enumerate(frequencies):
        # Each note starts a bit later
        start = int(i * SAMPLE_RATE * 0.3)
        end = int(SAMPLE_RATE * 1.0)
        segment_t = t[start:end]
        # Amplitude envelope
        amplitude = np.exp(-3 * (segment_t - i * 0.3 - 0.1))
        # Generate sine wave
        note = 0.4 * amplitude * np.sin(2 * np.pi * freq * segment_t)
        # Add to audio
        audio[start:end] += note
    
    # Ensure it's in int16 range
    audio = (audio * 32767).astype(np.int16)
    # Save to file
    wavfile.write('game_over.wav', SAMPLE_RATE, audio)

def create_button_click_sound():
    """Create a button click sound effect - short click"""
    t = np.linspace(0, 0.1, int(SAMPLE_RATE * 0.1), False)
    # Click is a mix of frequencies
    freq1, freq2 = 800, 1200
    # Very quick decay
    amplitude = np.exp(-30 * t)
    # Generate sound
    note = 0.5 * amplitude * (np.sin(2 * np.pi * freq1 * t) + np.sin(2 * np.pi * freq2 * t))
    # Ensure it's in int16 range
    audio = (note * 32767).astype(np.int16)
    # Save to file
    wavfile.write('button_click.wav', SAMPLE_RATE, audio)

def create_time_low_sound():
    """Create a time running low warning sound - pulsing beep"""
    t = np.linspace(0, 0.7, int(SAMPLE_RATE * 0.7), False)
    # Beep frequency
    frequency = 880  # A5
    # Pulsing amplitude (two pulses)
    amplitude = np.zeros_like(t)
    # First pulse
    pulse1_mask = (t >= 0.0) & (t < 0.2)
    amplitude[pulse1_mask] = np.exp(-5 * (t[pulse1_mask] - 0.1) ** 2)
    # Second pulse
    pulse2_mask = (t >= 0.4) & (t < 0.6)
    amplitude[pulse2_mask] = np.exp(-5 * (t[pulse2_mask] - 0.5) ** 2)
    # Generate sine wave
    note = 0.5 * amplitude * np.sin(2 * np.pi * frequency * t)
    # Ensure it's in int16 range
    audio = (note * 32767).astype(np.int16)
    # Save to file
    wavfile.write('time_low.wav', SAMPLE_RATE, audio)

if __name__ == "__main__":
    # Create all sound effects
    create_jump_sound()
    create_coin_sound()
    create_powerup_sound()
    create_crash_sound()
    create_game_over_sound()
    create_button_click_sound()
    create_time_low_sound()
    
    print("All sound effects created successfully!")
