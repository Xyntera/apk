import numpy as np
from scipy.io import wavfile
import os

# Define music parameters
SAMPLE_RATE = 44100  # Hz
BPM = 120  # Beats per minute
BEAT_DURATION = 60 / BPM  # Duration of one beat in seconds

def create_menu_music():
    """Create a simple looping menu music track"""
    # Duration: 16 beats (4 bars at 4/4)
    duration = 16 * BEAT_DURATION
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), False)
    
    # Base frequencies for a C major chord progression (C, G, Am, F)
    chord_progressions = [
        [261.63, 329.63, 392.00],  # C major (C, E, G)
        [392.00, 493.88, 587.33],  # G major (G, B, D)
        [220.00, 261.63, 329.63],  # A minor (A, C, E)
        [349.23, 440.00, 523.25]   # F major (F, A, C)
    ]
    
    # Create the audio array
    audio = np.zeros(int(SAMPLE_RATE * duration), dtype=np.float64)
    
    # Add chord progression (4 beats per chord)
    for i, chord in enumerate(chord_progressions):
        start_beat = i * 4
        start_time = start_beat * BEAT_DURATION
        end_time = (start_beat + 4) * BEAT_DURATION
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        segment_t = t[start_idx:end_idx]
        
        # Create a simple envelope for each chord
        envelope = np.ones_like(segment_t)
        attack = int(0.1 * BEAT_DURATION * SAMPLE_RATE)
        release = int(0.5 * BEAT_DURATION * SAMPLE_RATE)
        
        # Apply attack
        if attack > 0:
            envelope[:attack] = np.linspace(0, 1, attack)
        
        # Apply release
        if release > 0 and len(envelope) > release:
            envelope[-release:] = np.linspace(1, 0.3, release)
        
        # Add each note in the chord
        for note_freq in chord:
            note = 0.2 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
            audio[start_idx:end_idx] += note
    
    # Add a simple melody
    melody_notes = [523.25, 493.88, 440.00, 392.00, 440.00, 493.88, 523.25, 587.33]  # C5, B4, A4, G4, A4, B4, C5, D5
    melody_durations = [2, 1, 1, 2, 1, 1, 2, 2]  # in beats
    
    current_beat = 0
    for note_freq, note_duration in zip(melody_notes, melody_durations):
        start_time = current_beat * BEAT_DURATION
        end_time = (current_beat + note_duration) * BEAT_DURATION
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        if end_idx > len(audio):
            break
            
        segment_t = t[start_idx:end_idx]
        
        # Create a simple envelope for each note
        envelope = np.ones_like(segment_t)
        attack = int(0.05 * BEAT_DURATION * SAMPLE_RATE)
        release = int(0.3 * BEAT_DURATION * SAMPLE_RATE)
        
        # Apply attack
        if attack > 0 and len(envelope) > attack:
            envelope[:attack] = np.linspace(0, 1, attack)
        
        # Apply release
        if release > 0 and len(envelope) > release:
            envelope[-release:] = np.linspace(1, 0, release)
        
        # Add the melody note
        note = 0.3 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
        audio[start_idx:end_idx] += note
        
        current_beat += note_duration
    
    # Add a simple bass line
    bass_notes = [65.41, 98.00, 110.00, 87.31]  # C2, G2, A2, F2
    
    for i, note_freq in enumerate(bass_notes):
        start_beat = i * 4
        start_time = start_beat * BEAT_DURATION
        end_time = (start_beat + 4) * BEAT_DURATION
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        segment_t = t[start_idx:end_idx]
        
        # Create a rhythmic pattern for the bass
        for j in range(4):  # 4 beats per chord
            beat_start = start_idx + j * int(BEAT_DURATION * SAMPLE_RATE)
            beat_end = beat_start + int(0.5 * BEAT_DURATION * SAMPLE_RATE)
            
            if beat_end > len(audio):
                break
                
            beat_t = t[beat_start:beat_end]
            
            # Create envelope
            envelope = np.exp(-5 * np.linspace(0, 1, len(beat_t)))
            
            # Add the bass note
            note = 0.4 * envelope * np.sin(2 * np.pi * note_freq * beat_t)
            audio[beat_start:beat_end] += note
    
    # Normalize audio
    audio = audio / np.max(np.abs(audio))
    
    # Convert to int16
    audio_int16 = (audio * 32767).astype(np.int16)
    
    # Save to file
    wavfile.write('menu_music.wav', SAMPLE_RATE, audio_int16)

def create_gameplay_music():
    """Create a more energetic gameplay music track"""
    # Duration: 16 beats (4 bars at 4/4) but faster tempo
    faster_bpm = 140
    beat_duration = 60 / faster_bpm
    duration = 16 * beat_duration
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), False)
    
    # Base frequencies for a more energetic chord progression (Am, F, C, G)
    chord_progressions = [
        [220.00, 261.63, 329.63],  # A minor (A, C, E)
        [349.23, 440.00, 523.25],  # F major (F, A, C)
        [261.63, 329.63, 392.00],  # C major (C, E, G)
        [392.00, 493.88, 587.33]   # G major (G, B, D)
    ]
    
    # Create the audio array
    audio = np.zeros(int(SAMPLE_RATE * duration), dtype=np.float64)
    
    # Add chord progression (4 beats per chord)
    for i, chord in enumerate(chord_progressions):
        start_beat = i * 4
        start_time = start_beat * beat_duration
        end_time = (start_beat + 4) * beat_duration
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        segment_t = t[start_idx:end_idx]
        
        # Create a simple envelope for each chord
        envelope = np.ones_like(segment_t)
        attack = int(0.05 * beat_duration * SAMPLE_RATE)
        release = int(0.3 * beat_duration * SAMPLE_RATE)
        
        # Apply attack
        if attack > 0:
            envelope[:attack] = np.linspace(0, 1, attack)
        
        # Apply release
        if release > 0 and len(envelope) > release:
            envelope[-release:] = np.linspace(1, 0.3, release)
        
        # Add each note in the chord with a more electronic sound (add harmonics)
        for note_freq in chord:
            # Fundamental
            note = 0.15 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
            # First harmonic
            note += 0.1 * envelope * np.sin(2 * np.pi * note_freq * 2 * segment_t)
            # Second harmonic
            note += 0.05 * envelope * np.sin(2 * np.pi * note_freq * 3 * segment_t)
            
            audio[start_idx:end_idx] += note
    
    # Add a more complex melody
    melody_notes = [523.25, 587.33, 659.25, 783.99, 659.25, 587.33, 523.25, 493.88,
                   523.25, 587.33, 659.25, 783.99, 880.00, 783.99, 659.25, 587.33]
    melody_durations = [0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
                       0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1, 1]  # in beats
    
    current_beat = 0
    for note_freq, note_duration in zip(melody_notes, melody_durations):
        start_time = current_beat * beat_duration
        end_time = (current_beat + note_duration) * beat_duration
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        if end_idx > len(audio):
            break
            
        segment_t = t[start_idx:end_idx]
        
        # Create a simple envelope for each note
        envelope = np.ones_like(segment_t)
        attack = int(0.02 * beat_duration * SAMPLE_RATE)
        release = int(0.2 * beat_duration * SAMPLE_RATE)
        
        # Apply attack
        if attack > 0 and len(envelope) > attack:
            envelope[:attack] = np.linspace(0, 1, attack)
        
        # Apply release
        if release > 0 and len(envelope) > release:
            envelope[-release:] = np.linspace(1, 0, release)
        
        # Add the melody note with a slight vibrato effect
        vibrato_rate = 8  # Hz
        vibrato_depth = 0.01
        vibrato = vibrato_depth * np.sin(2 * np.pi * vibrato_rate * segment_t)
        note = 0.25 * envelope * np.sin(2 * np.pi * note_freq * (segment_t + vibrato))
        audio[start_idx:end_idx] += note
        
        current_beat += note_duration
    
    # Add a driving bass line
    bass_pattern = [0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0, 0, 0, 0, 0, 0, 0]  # 16th notes, 1 = accent
    bass_notes = [55.00, 87.31, 65.41, 98.00]  # A1, F2, C2, G2
    
    for i, note_freq in enumerate(bass_notes):
        start_beat = i * 4
        
        for j in range(16):  # 16 sixteenth notes per 4 beats
            sixteenth_idx = start_beat * 4 + j
            if sixteenth_idx >= len(bass_pattern):
                break
                
            start_time = (start_beat + j/4) * beat_duration
            end_time = (start_beat + (j+1)/4) * beat_duration
            
            start_idx = int(start_time * SAMPLE_RATE)
            end_idx = int(end_time * SAMPLE_RATE)
            
            if end_idx > len(audio):
                break
                
            segment_t = t[start_idx:end_idx]
            
            # Create envelope
            envelope = np.exp(-10 * np.linspace(0, 1, len(segment_t)))
            
            # Add the bass note
            note = 0.35 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
            # Add some harmonics for a richer sound
            note += 0.15 * envelope * np.sin(2 * np.pi * note_freq * 2 * segment_t)
            
            audio[start_idx:end_idx] += note
    
    # Add a simple drum beat
    kick_pattern = [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0]  # 16th notes
    snare_pattern = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0]  # 16th notes
    hihat_pattern = [1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0]  # 16th notes
    
    # Repeat patterns for all 4 bars
    for bar in range(4):
        for j in range(16):  # 16 sixteenth notes per bar
            sixteenth_idx = j
            
            start_time = (bar * 4 + j/4) * beat_duration
            end_time = (bar * 4 + (j+1)/4) * beat_duration
            
            start_idx = int(start_time * SAMPLE_RATE)
            end_idx = int(end_time * SAMPLE_RATE)
            
            if end_idx > len(audio):
                break
                
            segment_t = t[start_idx:end_idx]
            
            # Add kick drum
            if kick_pattern[sixteenth_idx]:
                # Create kick drum sound (low frequency sine with quick decay)
                envelope = np.exp(-20 * np.linspace(0, 1, len(segment_t)))
                kick = 0.5 * envelope * np.sin(2 * np.pi * 60 * segment_t)
                audio[start_idx:end_idx] += kick
            
            # Add snare drum
            if snare_pattern[sixteenth_idx]:
                # Create snare drum sound (noise with quick decay)
                envelope = np.exp(-15 * np.linspace(0, 1, len(segment_t)))
                noise = np.random.uniform(-1, 1, len(segment_t))
                snare = 0.3 * envelope * noise
                # Add a bit of tone
                snare += 0.1 * envelope * np.sin(2 * np.pi * 180 * segment_t)
                audio[start_idx:end_idx] += snare
            
            # Add hi-hat
            if hihat_pattern[sixteenth_idx]:
                # Create hi-hat sound (high frequency noise with very quick decay)
                envelope = np.exp(-40 * np.linspace(0, 1, len(segment_t)))
                noise = np.random.uniform(-1, 1, len(segment_t))
                # Filter to get more high frequencies
                hihat = 0.15 * envelope * noise * np.sin(2 * np.pi * 8000 * segment_t)
                audio[start_idx:end_idx] += hihat
    
    # Normalize audio
    audio = audio / np.max(np.abs(audio))
    
    # Convert to int16
    audio_int16 = (audio * 32767).astype(np.int16)
    
    # Save to file
    wavfile.write('gameplay_music.wav', SAMPLE_RATE, audio_int16)

def create_game_over_music():
    """Create a short game over music jingle"""
    # Duration: 4 seconds
    duration = 4
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), False)
    
    # Create the audio array
    audio = np.zeros(int(SAMPLE_RATE * duration), dtype=np.float64)
    
    # Create a descending melody
    melody_notes = [523.25, 493.88, 440.00, 392.00, 349.23, 329.63, 293.66, 261.63]  # C5 to C4
    note_duration = 0.25  # seconds
    
    for i, note_freq in enumerate(melody_notes):
        start_time = i * note_duration
        end_time = (i + 1) * note_duration
        
        start_idx = int(start_time * SAMPLE_RATE)
        end_idx = int(end_time * SAMPLE_RATE)
        
        if end_idx > len(audio):
            break
            
        segment_t = t[start_idx:end_idx]
        
        # Create envelope
        envelope = np.ones_like(segment_t)
        attack = int(0.05 * note_duration * SAMPLE_RATE)
        release = int(0.2 * note_duration * SAMPLE_RATE)
        
        # Apply attack
        if attack > 0 and len(envelope) > attack:
            envelope[:attack] = np.linspace(0, 1, attack)
        
        # Apply release
        if release > 0 and len(envelope) > release:
            envelope[-release:] = np.linspace(1, 0, release)
        
        # Add the note
        note = 0.3 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
        audio[start_idx:end_idx] += note
    
    # Add a final chord
    final_chord = [261.63, 329.63, 392.00]  # C major (C4, E4, G4)
    start_time = len(melody_notes) * note_duration
    end_time = duration
    
    start_idx = int(start_time * SAMPLE_RATE)
    end_idx = int(end_time * SAMPLE_RATE)
    
    segment_t = t[start_idx:end_idx]
    
    # Create envelope
    envelope = np.exp(-1 * np.linspace(0, 1, len(segment_t)))
    
    # Add each note in the chord
    for note_freq in final_chord:
        note = 0.25 * envelope * np.sin(2 * np.pi * note_freq * segment_t)
        audio[start_idx:end_idx] += note
    
    # Normalize audio
    audio = audio / np.max(np.abs(audio))
    
    # Convert to int16
    audio_int16 = (audio * 32767).astype(np.int16)
    
    # Save to file
    wavfile.write('game_over_music.wav', SAMPLE_RATE, audio_int16)

if __name__ == "__main__":
    # Create all music tracks
    create_menu_music()
    create_gameplay_music()
    create_game_over_music()
    
    print("All music tracks created successfully!")
