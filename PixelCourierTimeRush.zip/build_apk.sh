#!/bin/bash

# Script to build and sign the APK for Pixel Courier: Time Rush

echo "Starting APK build process for Pixel Courier: Time Rush..."

# Create keystore directory if it doesn't exist
mkdir -p /home/ubuntu/PixelCourierTimeRush/keystore

# Generate keystore if it doesn't exist
if [ ! -f /home/ubuntu/PixelCourierTimeRush/keystore/pixel_courier.keystore ]; then
    echo "Generating keystore..."
    keytool -genkey -v -keystore /home/ubuntu/PixelCourierTimeRush/keystore/pixel_courier.keystore \
        -alias pixel_courier -keyalg RSA -keysize 2048 -validity 10000 \
        -dname "CN=Pixel Courier, OU=Game Development, O=Manus AI, L=Virtual, S=AI, C=US" \
        -storepass pixelcourier -keypass pixelcourier
fi

# Create build directory
mkdir -p /home/ubuntu/PixelCourierTimeRush/build

# Compile Java files
echo "Compiling Java files..."
mkdir -p /home/ubuntu/PixelCourierTimeRush/build/classes
javac -d /home/ubuntu/PixelCourierTimeRush/build/classes \
    -sourcepath /home/ubuntu/PixelCourierTimeRush/android/src/main/java \
    /home/ubuntu/PixelCourierTimeRush/android/src/main/java/com/pixelcourier/timerush/**/*.java

# Create resources directory in build
mkdir -p /home/ubuntu/PixelCourierTimeRush/build/res

# Copy resources
echo "Copying resources..."
cp -r /home/ubuntu/PixelCourierTimeRush/android/src/main/res/* /home/ubuntu/PixelCourierTimeRush/build/res/

# Create assets directory in build
mkdir -p /home/ubuntu/PixelCourierTimeRush/build/assets

# Copy assets
echo "Copying assets..."
cp -r /home/ubuntu/PixelCourierTimeRush/android/src/main/assets/* /home/ubuntu/PixelCourierTimeRush/build/assets/

# Create AndroidManifest.xml in build directory
cp /home/ubuntu/PixelCourierTimeRush/android/src/main/AndroidManifest.xml /home/ubuntu/PixelCourierTimeRush/build/

# Package resources into APK
echo "Packaging resources into APK..."
aapt package -f -M /home/ubuntu/PixelCourierTimeRush/build/AndroidManifest.xml \
    -S /home/ubuntu/PixelCourierTimeRush/build/res \
    -A /home/ubuntu/PixelCourierTimeRush/build/assets \
    -I /usr/lib/android-sdk/platforms/android-31/android.jar \
    -F /home/ubuntu/PixelCourierTimeRush/build/PixelCourierTimeRush-unaligned.apk \
    /home/ubuntu/PixelCourierTimeRush/build/classes

# Add classes to APK
echo "Adding classes to APK..."
cd /home/ubuntu/PixelCourierTimeRush/build/classes
jar uf ../PixelCourierTimeRush-unaligned.apk com

# Sign APK
echo "Signing APK..."
jarsigner -sigalg SHA1withRSA -digestalg SHA1 -keystore /home/ubuntu/PixelCourierTimeRush/keystore/pixel_courier.keystore \
    -storepass pixelcourier \
    /home/ubuntu/PixelCourierTimeRush/build/PixelCourierTimeRush-unaligned.apk pixel_courier

# Align APK
echo "Aligning APK..."
zipalign -f 4 /home/ubuntu/PixelCourierTimeRush/build/PixelCourierTimeRush-unaligned.apk \
    /home/ubuntu/PixelCourierTimeRush/PixelCourierTimeRush.apk

echo "APK build complete: /home/ubuntu/PixelCourierTimeRush/PixelCourierTimeRush.apk"
